using System.Security.Claims;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using UniversityCourseManagement.Api.Common;
using UniversityCourseManagement.Api.Data;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Models;
using UniversityCourseManagement.Api.Security;

namespace UniversityCourseManagement.Api.Services;

public interface IAuthService
{
    Task<UserDto> RegisterAsync(RegisterRequest request, CancellationToken ct = default);
    Task<LoginResponse> LoginAsync(LoginRequest request, CancellationToken ct = default);
    Task<UserDto> GetCurrentUserAsync(ClaimsPrincipal principal, CancellationToken ct = default);
}

public class AuthService : IAuthService
{
    private const string InvalidCredentials = "Неверное имя пользователя или пароль.";

    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly ITokenService _tokenService;
    private readonly AppDbContext _db;
    private readonly ILogger<AuthService> _logger;

    public AuthService(
        UserManager<ApplicationUser> userManager,
        SignInManager<ApplicationUser> signInManager,
        ITokenService tokenService,
        AppDbContext db,
        ILogger<AuthService> logger)
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _tokenService = tokenService;
        _db = db;
        _logger = logger;
    }

    public async Task<UserDto> RegisterAsync(RegisterRequest request, CancellationToken ct = default)
    {
        if (await _userManager.FindByNameAsync(request.UserName) is not null)
            throw new ConflictException($"Пользователь '{request.UserName}' уже существует.");

        var user = new ApplicationUser { UserName = request.UserName, Email = request.Email };

        // Пароль хешируется средствами Identity (PasswordHasher, PBKDF2) — своего хеширования нет
        var result = await _userManager.CreateAsync(user, request.Password);
        if (!result.Succeeded)
            throw ToBadRequest(result, "Не удалось зарегистрировать пользователя.");

        // Новый пользователь получает только базовую роль Student. Admin через регистрацию — невозможен.
        var roleResult = await _userManager.AddToRoleAsync(user, Roles.Student);
        if (!roleResult.Succeeded)
            throw ToBadRequest(roleResult, "Не удалось назначить роль.");

        _logger.LogInformation("User {UserName} registered", user.UserName);
        return await BuildUserDtoAsync(user, ct);
    }

    public async Task<LoginResponse> LoginAsync(LoginRequest request, CancellationToken ct = default)
    {
        var user = await _userManager.FindByNameAsync(request.UserName);
        if (user is null)
        {
            _logger.LogWarning("Login failed: unknown user");
            throw new UnauthorizedException(InvalidCredentials);
        }

        // Проверка пароля через Identity + учёт неудачных попыток (lockoutOnFailure: true)
        var result = await _signInManager.CheckPasswordSignInAsync(user, request.Password, lockoutOnFailure: true);

        if (result.IsLockedOut)
        {
            _logger.LogWarning("Login blocked: account {UserName} is locked out", user.UserName);
            throw new AccountLockedException(
                "Учётная запись временно заблокирована из-за нескольких неудачных попыток входа. Повторите позже.");
        }

        if (!result.Succeeded)
        {
            _logger.LogWarning("Login failed for {UserName}", user.UserName);
            throw new UnauthorizedException(InvalidCredentials);
        }

        var roles = await _userManager.GetRolesAsync(user);
        var profileClaims = await GetProfileClaimsAsync(user.Id, ct);
        var token = _tokenService.CreateAccessToken(user, roles, profileClaims);

        _logger.LogInformation("User {UserName} logged in", user.UserName); // сам токен НЕ логируется

        return new LoginResponse
        {
            AccessToken = token.Token,
            TokenType = "Bearer",
            ExpiresAtUtc = token.ExpiresAtUtc,
            UserName = user.UserName!,
            Roles = roles.ToList()
        };
    }

    public async Task<UserDto> GetCurrentUserAsync(ClaimsPrincipal principal, CancellationToken ct = default)
    {
        var userId = principal.GetUserId() ?? throw new UnauthorizedException("Токен не содержит идентификатор пользователя.");
        var user = await _userManager.FindByIdAsync(userId)
                   ?? throw new UnauthorizedException("Пользователь не найден.");
        return await BuildUserDtoAsync(user, ct);
    }

    /// <summary>student_id / teacher_id — связь аккаунта с сущностями Student/Teacher.</summary>
    private async Task<List<Claim>> GetProfileClaimsAsync(string userId, CancellationToken ct)
    {
        var claims = new List<Claim>();

        var studentId = await _db.Students.AsNoTracking()
            .Where(s => s.UserId == userId).Select(s => (int?)s.Id).FirstOrDefaultAsync(ct);
        if (studentId is not null)
            claims.Add(new Claim(AppClaimTypes.StudentId, studentId.Value.ToString()));

        var teacherId = await _db.Teachers.AsNoTracking()
            .Where(t => t.UserId == userId).Select(t => (int?)t.Id).FirstOrDefaultAsync(ct);
        if (teacherId is not null)
            claims.Add(new Claim(AppClaimTypes.TeacherId, teacherId.Value.ToString()));

        return claims;
    }

    private async Task<UserDto> BuildUserDtoAsync(ApplicationUser user, CancellationToken ct)
    {
        var roles = await _userManager.GetRolesAsync(user);
        return new UserDto
        {
            Id = user.Id,
            UserName = user.UserName ?? string.Empty,
            Email = user.Email,
            Roles = roles.ToList(),
            StudentId = await _db.Students.AsNoTracking()
                .Where(s => s.UserId == user.Id).Select(s => (int?)s.Id).FirstOrDefaultAsync(ct),
            TeacherId = await _db.Teachers.AsNoTracking()
                .Where(t => t.UserId == user.Id).Select(t => (int?)t.Id).FirstOrDefaultAsync(ct),
            IsLockedOut = await _userManager.IsLockedOutAsync(user)
        };
    }

    internal static BadRequestException ToBadRequest(IdentityResult result, string message) =>
        new(message, result.Errors
            .GroupBy(e => e.Code)
            .ToDictionary(g => g.Key, g => g.Select(e => e.Description).ToArray()));
}
