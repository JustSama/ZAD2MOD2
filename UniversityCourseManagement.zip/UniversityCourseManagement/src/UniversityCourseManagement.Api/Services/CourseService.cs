using AutoMapper;
using Microsoft.EntityFrameworkCore;
using UniversityCourseManagement.Api.Common;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Models;
using UniversityCourseManagement.Api.Repositories;
using UniversityCourseManagement.Api.Security;

namespace UniversityCourseManagement.Api.Services;

/// <summary>
/// Общая бизнес-логика курсов для ВСЕХ версий API.
/// v1 и v2 вызывают одни и те же методы, отличается только тип DTO (TDto),
/// поэтому логика не дублируется между версиями.
/// </summary>
public interface ICourseService
{
    Task<IReadOnlyList<TDto>> GetAllAsync<TDto>(CancellationToken ct = default);
    Task<TDto> GetByIdAsync<TDto>(int id, CancellationToken ct = default);
    Task<CourseDto> CreateAsync(SaveCourseDto dto, CancellationToken ct = default);
    Task UpdateAsync(int id, SaveCourseDto dto, CancellationToken ct = default);
    Task DeleteAsync(int id, CancellationToken ct = default);

    /// <summary>Список записей курса (с оценками) — только преподаватель курса или Admin.</summary>
    Task<IReadOnlyList<EnrollmentDto>> GetEnrollmentsAsync(int courseId, CancellationToken ct = default);
}

public class CourseService : ICourseService
{
    private readonly IRepository<Course> _courses;
    private readonly IRepository<Teacher> _teachers;
    private readonly IRepository<Enrollment> _enrollments;
    private readonly IMapper _mapper;
    private readonly ICurrentUser _currentUser;

    public CourseService(
        IRepository<Course> courses,
        IRepository<Teacher> teachers,
        IRepository<Enrollment> enrollments,
        IMapper mapper,
        ICurrentUser currentUser)
    {
        _courses = courses;
        _teachers = teachers;
        _enrollments = enrollments;
        _mapper = mapper;
        _currentUser = currentUser;
    }

    private IQueryable<Course> CoursesWithDetails() =>
        _courses.Query()
            .Include(c => c.Teacher)
            .Include(c => c.Enrollments)
            .AsSplitQuery();

    public async Task<IReadOnlyList<TDto>> GetAllAsync<TDto>(CancellationToken ct = default)
    {
        var list = await CoursesWithDetails().OrderBy(c => c.Code).ToListAsync(ct);
        return _mapper.Map<List<TDto>>(list);
    }

    public async Task<TDto> GetByIdAsync<TDto>(int id, CancellationToken ct = default)
    {
        var course = await CoursesWithDetails().FirstOrDefaultAsync(c => c.Id == id, ct)
                     ?? throw new NotFoundException($"Курс {id} не найден.");
        return _mapper.Map<TDto>(course);
    }

    public async Task<CourseDto> CreateAsync(SaveCourseDto dto, CancellationToken ct = default)
    {
        await ValidateAsync(dto, null, ct);
        var entity = _mapper.Map<Course>(dto);
        await _courses.AddAsync(entity, ct);
        await _courses.SaveChangesAsync(ct);
        return _mapper.Map<CourseDto>(entity);
    }

    public async Task UpdateAsync(int id, SaveCourseDto dto, CancellationToken ct = default)
    {
        var entity = await _courses.GetByIdAsync(id, ct)
                     ?? throw new NotFoundException($"Курс {id} не найден.");
        await ValidateAsync(dto, id, ct);
        _mapper.Map(dto, entity);
        await _courses.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(int id, CancellationToken ct = default)
    {
        var entity = await _courses.GetByIdAsync(id, ct)
                     ?? throw new NotFoundException($"Курс {id} не найден.");
        _courses.Remove(entity);
        await _courses.SaveChangesAsync(ct);
    }

    public async Task<IReadOnlyList<EnrollmentDto>> GetEnrollmentsAsync(int courseId, CancellationToken ct = default)
    {
        var course = await _courses.Query().FirstOrDefaultAsync(c => c.Id == courseId, ct)
                     ?? throw new NotFoundException($"Курс {courseId} не найден.");

        await _currentUser.EnsureAuthorizedAsync(course, Policies.CourseOwner,
            "Просматривать записи и оценки может только преподаватель этого курса.");

        var list = await _enrollments.Query()
            .Include(e => e.Student)
            .Include(e => e.Course)
            .Where(e => e.CourseId == courseId)
            .OrderBy(e => e.Student.LastName)
            .ToListAsync(ct);
        return _mapper.Map<List<EnrollmentDto>>(list);
    }

    private async Task ValidateAsync(SaveCourseDto dto, int? exceptId, CancellationToken ct)
    {
        if (await _courses.Query().AnyAsync(c => c.Code == dto.Code && c.Id != exceptId, ct))
            throw new ConflictException($"Курс с кодом {dto.Code} уже существует.");

        if (dto.TeacherId is not null && !await _teachers.Query().AnyAsync(t => t.Id == dto.TeacherId, ct))
            throw new BadRequestException($"Преподаватель {dto.TeacherId} не найден.");
    }
}
