using AutoMapper;
using Microsoft.EntityFrameworkCore;
using UniversityCourseManagement.Api.Common;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Models;
using UniversityCourseManagement.Api.Repositories;
using UniversityCourseManagement.Api.Security;

namespace UniversityCourseManagement.Api.Services;

public interface IStudentService
{
    Task<IReadOnlyList<StudentDto>> GetAllAsync(CancellationToken ct = default);
    Task<StudentDto> GetByIdAsync(int id, CancellationToken ct = default);
    Task<StudentDto> CreateAsync(SaveStudentDto dto, CancellationToken ct = default);
    Task UpdateAsync(int id, SaveStudentDto dto, CancellationToken ct = default);
    Task DeleteAsync(int id, CancellationToken ct = default);

    /// <summary>Записи и оценки студента. Студент видит только свои.</summary>
    Task<IReadOnlyList<EnrollmentDto>> GetEnrollmentsAsync(int studentId, CancellationToken ct = default);
}

public class StudentService : IStudentService
{
    private readonly IRepository<Student> _students;
    private readonly IRepository<Enrollment> _enrollments;
    private readonly IMapper _mapper;
    private readonly ICurrentUser _currentUser;

    public StudentService(
        IRepository<Student> students,
        IRepository<Enrollment> enrollments,
        IMapper mapper,
        ICurrentUser currentUser)
    {
        _students = students;
        _enrollments = enrollments;
        _mapper = mapper;
        _currentUser = currentUser;
    }

    public async Task<IReadOnlyList<StudentDto>> GetAllAsync(CancellationToken ct = default)
    {
        var list = await _students.Query().OrderBy(s => s.LastName).ToListAsync(ct);
        return _mapper.Map<List<StudentDto>>(list);
    }

    public async Task<StudentDto> GetByIdAsync(int id, CancellationToken ct = default)
    {
        // Admin/Teacher — любой студент; Student — только свой профиль
        if (!_currentUser.IsInRole(Roles.Admin) && !_currentUser.IsInRole(Roles.Teacher))
            await _currentUser.EnsureAuthorizedAsync(new StudentResource(id), Policies.StudentDataOwner);

        var student = await _students.Query().FirstOrDefaultAsync(s => s.Id == id, ct)
                      ?? throw new NotFoundException($"Студент {id} не найден.");
        return _mapper.Map<StudentDto>(student);
    }

    public async Task<StudentDto> CreateAsync(SaveStudentDto dto, CancellationToken ct = default)
    {
        await EnsureEmailUniqueAsync(dto.Email, null, ct);
        var entity = _mapper.Map<Student>(dto);
        await _students.AddAsync(entity, ct);
        await _students.SaveChangesAsync(ct);
        return _mapper.Map<StudentDto>(entity);
    }

    public async Task UpdateAsync(int id, SaveStudentDto dto, CancellationToken ct = default)
    {
        var entity = await _students.GetByIdAsync(id, ct)
                     ?? throw new NotFoundException($"Студент {id} не найден.");
        await EnsureEmailUniqueAsync(dto.Email, id, ct);
        _mapper.Map(dto, entity);
        await _students.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(int id, CancellationToken ct = default)
    {
        var entity = await _students.GetByIdAsync(id, ct)
                     ?? throw new NotFoundException($"Студент {id} не найден.");
        _students.Remove(entity);
        await _students.SaveChangesAsync(ct);
    }

    public async Task<IReadOnlyList<EnrollmentDto>> GetEnrollmentsAsync(int studentId, CancellationToken ct = default)
    {
        // Проверка владения: роль Student недостаточна — нужен СВОЙ studentId
        await _currentUser.EnsureAuthorizedAsync(
            new StudentResource(studentId), Policies.StudentDataOwner,
            "Нельзя просматривать оценки другого студента.");

        if (!await _students.Query().AnyAsync(s => s.Id == studentId, ct))
            throw new NotFoundException($"Студент {studentId} не найден.");

        var list = await _enrollments.Query()
            .Include(e => e.Student)
            .Include(e => e.Course)
            .Where(e => e.StudentId == studentId)
            .OrderBy(e => e.Course.Code)
            .ToListAsync(ct);
        return _mapper.Map<List<EnrollmentDto>>(list);
    }

    private async Task EnsureEmailUniqueAsync(string email, int? exceptId, CancellationToken ct)
    {
        if (await _students.Query().AnyAsync(s => s.Email == email && s.Id != exceptId, ct))
            throw new ConflictException($"Студент с email {email} уже существует.");
    }
}
