using AutoMapper;
using Microsoft.EntityFrameworkCore;
using UniversityCourseManagement.Api.Common;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Models;
using UniversityCourseManagement.Api.Repositories;
using UniversityCourseManagement.Api.Security;

namespace UniversityCourseManagement.Api.Services;

public interface IEnrollmentService
{
    Task<IReadOnlyList<EnrollmentDto>> GetAllAsync(CancellationToken ct = default);
    Task<EnrollmentDto> GetByIdAsync(int id, CancellationToken ct = default);
    Task<IReadOnlyList<EnrollmentDto>> GetMyAsync(CancellationToken ct = default);
    Task<EnrollmentDto> CreateAsync(CreateEnrollmentDto dto, CancellationToken ct = default);
    Task<EnrollmentDto> UpdateGradeAsync(int id, int grade, CancellationToken ct = default);
    Task DeleteAsync(int id, CancellationToken ct = default);
}

public class EnrollmentService : IEnrollmentService
{
    private readonly IRepository<Enrollment> _enrollments;
    private readonly IRepository<Student> _students;
    private readonly IRepository<Course> _courses;
    private readonly IMapper _mapper;
    private readonly ICurrentUser _currentUser;
    private readonly ILogger<EnrollmentService> _logger;

    public EnrollmentService(
        IRepository<Enrollment> enrollments,
        IRepository<Student> students,
        IRepository<Course> courses,
        IMapper mapper,
        ICurrentUser currentUser,
        ILogger<EnrollmentService> logger)
    {
        _enrollments = enrollments;
        _students = students;
        _courses = courses;
        _mapper = mapper;
        _currentUser = currentUser;
        _logger = logger;
    }

    private IQueryable<Enrollment> WithDetails(IQueryable<Enrollment> q) =>
        q.Include(e => e.Student).Include(e => e.Course);

    public async Task<IReadOnlyList<EnrollmentDto>> GetAllAsync(CancellationToken ct = default)
    {
        var list = await WithDetails(_enrollments.Query()).OrderBy(e => e.Id).ToListAsync(ct);
        return _mapper.Map<List<EnrollmentDto>>(list);
    }

    public async Task<EnrollmentDto> GetByIdAsync(int id, CancellationToken ct = default)
    {
        var enrollment = await WithDetails(_enrollments.Query()).FirstOrDefaultAsync(e => e.Id == id, ct)
                         ?? throw new NotFoundException($"Запись {id} не найдена.");

        await _currentUser.EnsureAuthorizedAsync(enrollment, Policies.EnrollmentViewer);
        return _mapper.Map<EnrollmentDto>(enrollment);
    }

    public async Task<IReadOnlyList<EnrollmentDto>> GetMyAsync(CancellationToken ct = default)
    {
        var studentId = _currentUser.Principal.GetStudentId()
                        ?? throw new ForbiddenAccessException("Учётная запись не связана с профилем студента.");

        var list = await WithDetails(_enrollments.Query())
            .Where(e => e.StudentId == studentId)
            .OrderBy(e => e.Course.Code)
            .ToListAsync(ct);
        return _mapper.Map<List<EnrollmentDto>>(list);
    }

    public async Task<EnrollmentDto> CreateAsync(CreateEnrollmentDto dto, CancellationToken ct = default)
    {
        // Admin записывает любого; Student — только себя
        await _currentUser.EnsureAuthorizedAsync(new StudentResource(dto.StudentId), Policies.StudentDataOwner,
            "Студент может записать на курс только себя.");

        if (!await _students.Query().AnyAsync(s => s.Id == dto.StudentId, ct))
            throw new NotFoundException($"Студент {dto.StudentId} не найден.");
        if (!await _courses.Query().AnyAsync(c => c.Id == dto.CourseId, ct))
            throw new NotFoundException($"Курс {dto.CourseId} не найден.");
        if (await _enrollments.Query().AnyAsync(e => e.StudentId == dto.StudentId && e.CourseId == dto.CourseId, ct))
            throw new ConflictException("Студент уже записан на этот курс.");

        var entity = new Enrollment
        {
            StudentId = dto.StudentId,
            CourseId = dto.CourseId,
            EnrolledAt = DateTime.UtcNow
        };
        await _enrollments.AddAsync(entity, ct);
        await _enrollments.SaveChangesAsync(ct);

        return await GetDtoAsync(entity.Id, ct);
    }

    public async Task<EnrollmentDto> UpdateGradeAsync(int id, int grade, CancellationToken ct = default)
    {
        var enrollment = await _enrollments.QueryTracked()
                             .Include(e => e.Course)
                             .FirstOrDefaultAsync(e => e.Id == id, ct)
                         ?? throw new NotFoundException($"Запись {id} не найдена.");

        // Роль Teacher уже проверена атрибутом. Здесь — проверка ПРИНАДЛЕЖНОСТИ курса:
        // course.TeacherId должен совпадать с teacher_id из JWT (Admin — без ограничений).
        await _currentUser.EnsureAuthorizedAsync(enrollment.Course, Policies.CourseOwner,
            "Преподаватель может изменять оценки только по своим курсам.");

        enrollment.Grade = grade;
        await _enrollments.SaveChangesAsync(ct);

        _logger.LogInformation("Grade updated for enrollment {EnrollmentId} by user {UserId}",
            id, _currentUser.Principal.GetUserId());

        return await GetDtoAsync(id, ct);
    }

    public async Task DeleteAsync(int id, CancellationToken ct = default)
    {
        var entity = await _enrollments.GetByIdAsync(id, ct)
                     ?? throw new NotFoundException($"Запись {id} не найдена.");
        _enrollments.Remove(entity);
        await _enrollments.SaveChangesAsync(ct);
    }

    private async Task<EnrollmentDto> GetDtoAsync(int id, CancellationToken ct)
    {
        var e = await WithDetails(_enrollments.Query()).FirstAsync(x => x.Id == id, ct);
        return _mapper.Map<EnrollmentDto>(e);
    }
}
