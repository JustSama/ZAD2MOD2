using AutoMapper;
using Microsoft.EntityFrameworkCore;
using UniversityCourseManagement.Api.Common;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Models;
using UniversityCourseManagement.Api.Repositories;

namespace UniversityCourseManagement.Api.Services;

public interface ITeacherService
{
    Task<IReadOnlyList<TeacherDto>> GetAllAsync(CancellationToken ct = default);
    Task<TeacherDto> GetByIdAsync(int id, CancellationToken ct = default);
    Task<TeacherDto> CreateAsync(SaveTeacherDto dto, CancellationToken ct = default);
    Task UpdateAsync(int id, SaveTeacherDto dto, CancellationToken ct = default);
    Task DeleteAsync(int id, CancellationToken ct = default);
}

public class TeacherService : ITeacherService
{
    private readonly IRepository<Teacher> _teachers;
    private readonly IMapper _mapper;

    public TeacherService(IRepository<Teacher> teachers, IMapper mapper)
    {
        _teachers = teachers;
        _mapper = mapper;
    }

    public async Task<IReadOnlyList<TeacherDto>> GetAllAsync(CancellationToken ct = default)
    {
        var list = await _teachers.Query().OrderBy(t => t.LastName).ToListAsync(ct);
        return _mapper.Map<List<TeacherDto>>(list);
    }

    public async Task<TeacherDto> GetByIdAsync(int id, CancellationToken ct = default)
    {
        var teacher = await _teachers.Query().FirstOrDefaultAsync(t => t.Id == id, ct)
                      ?? throw new NotFoundException($"Преподаватель {id} не найден.");
        return _mapper.Map<TeacherDto>(teacher);
    }

    public async Task<TeacherDto> CreateAsync(SaveTeacherDto dto, CancellationToken ct = default)
    {
        await EnsureEmailUniqueAsync(dto.Email, null, ct);
        var entity = _mapper.Map<Teacher>(dto);
        await _teachers.AddAsync(entity, ct);
        await _teachers.SaveChangesAsync(ct);
        return _mapper.Map<TeacherDto>(entity);
    }

    public async Task UpdateAsync(int id, SaveTeacherDto dto, CancellationToken ct = default)
    {
        var entity = await _teachers.GetByIdAsync(id, ct)
                     ?? throw new NotFoundException($"Преподаватель {id} не найден.");
        await EnsureEmailUniqueAsync(dto.Email, id, ct);
        _mapper.Map(dto, entity);
        await _teachers.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(int id, CancellationToken ct = default)
    {
        var entity = await _teachers.GetByIdAsync(id, ct)
                     ?? throw new NotFoundException($"Преподаватель {id} не найден.");
        _teachers.Remove(entity);
        await _teachers.SaveChangesAsync(ct);
    }

    private async Task EnsureEmailUniqueAsync(string email, int? exceptId, CancellationToken ct)
    {
        if (await _teachers.Query().AnyAsync(t => t.Email == email && t.Id != exceptId, ct))
            throw new ConflictException($"Преподаватель с email {email} уже существует.");
    }
}
