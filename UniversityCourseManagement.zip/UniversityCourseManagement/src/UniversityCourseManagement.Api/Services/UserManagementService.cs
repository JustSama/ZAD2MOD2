using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using UniversityCourseManagement.Api.Common;
using UniversityCourseManagement.Api.Data;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Models;
using UniversityCourseManagement.Api.Security;

namespace UniversityCourseManagement.Api.Services;

/// <summary>Управление пользователями и ролями — доступно только Admin.</summary>
public interface IUserManagementService
{
    Task<IReadOnlyList<UserDto>> GetUsersAsync(CancellationToken ct = default);
    Task<UserDto> GetUserAsync(string userId, CancellationToken ct = default);
    Task<IReadOnlyList<string>> GetRolesAsync(CancellationToken ct = default);
    Task CreateRoleAsync(string name, CancellationToken ct = default);
    Task<UserDto> AssignRoleAsync(string userId, string role, CancellationToken ct = default);
    Task<UserDto> RemoveRoleAsync(string userId, string role, CancellationToken ct = default);
    Task<UserDto> LinkStudentAsync(string userId, int studentId, CancellationToken ct = default);
    Task<UserDto> LinkTeacherAsync(string userId, int teacherId, CancellationToken ct = default);
    Task<UserDto> UnlockAsync(string userId, CancellationToken ct = default);
}

public class UserManagementService : IUserManagementService
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly RoleManager<IdentityRole> _roleManager;
    private readonly AppDbContext _db;
    private readonly ICurrentUser _currentUser;
    private readonly ILogger<UserManagementService> _logger;

    public UserManagementService(
        UserManager<ApplicationUser> userManager,
        RoleManager<IdentityRole> roleManager,
        AppDbContext db,
        ICurrentUser currentUser,
        ILogger<UserManagementService> logger)
    {
        _userManager = userManager;
        _roleManager = roleManager;
        _db = db;
        _currentUser = currentUser;
        _logger = logger;
    }

    public async Task<IReadOnlyList<UserDto>> GetUsersAsync(CancellationToken ct = default)
    {
        var users = await _userManager.Users.AsNoTracking().OrderBy(u => u.UserName).ToListAsync(ct);
        var result = new List<UserDto>(users.Count);
        foreach (var user in users)
            result.Add(await ToDtoAsync(user, ct));
        return result;
    }

    public async Task<UserDto> GetUserAsync(string userId, CancellationToken ct = default) =>
        await ToDtoAsync(await FindUserAsync(userId), ct);

    public async Task<IReadOnlyList<string>> GetRolesAsync(CancellationToken ct = default) =>
        await _roleManager.Roles.AsNoTracking().OrderBy(r => r.Name).Select(r => r.Name!).ToListAsync(ct);

    public async Task CreateRoleAsync(string name, CancellationToken ct = default)
    {
        if (await _roleManager.RoleExistsAsync(name))
            throw new ConflictException($"Роль '{name}' уже существует.");

        var result = await _roleManager.CreateAsync(new IdentityRole(name));
        if (!result.Succeeded)
            throw AuthService.ToBadRequest(result, "Не удалось создать роль.");
    }

    public async Task<UserDto> AssignRoleAsync(string userId, string role, CancellationToken ct = default)
    {
        var user = await FindUserAsync(userId);
        if (!await _roleManager.RoleExistsAsync(role))
            throw new BadRequestException($"Роль '{role}' не существует.");

        if (await _userManager.IsInRoleAsync(user, role))
            throw new ConflictException($"У пользователя уже есть роль '{role}'.");

        var result = await _userManager.AddToRoleAsync(user, role);
        if (!result.Succeeded)
            throw AuthService.ToBadRequest(result, "Не удалось назначить роль.");

        _logger.LogInformation("Role {Role} assigned to user {TargetUserId} by {AdminUserId}",
            role, userId, _currentUser.Principal.GetUserId());
        return await ToDtoAsync(user, ct);
    }

    public async Task<UserDto> RemoveRoleAsync(string userId, string role, CancellationToken ct = default)
    {
        var user = await FindUserAsync(userId);

        // Защита от «запирания» системы: админ не может снять Admin сам с себя
        if (role == Roles.Admin && userId == _currentUser.Principal.GetUserId())
            throw new BadRequestException("Нельзя снять роль Admin с собственной учётной записи.");

        if (!await _userManager.IsInRoleAsync(user, role))
            throw new NotFoundException($"У пользователя нет роли '{role}'.");

        var result = await _userManager.RemoveFromRoleAsync(user, role);
        if (!result.Succeeded)
            throw AuthService.ToBadRequest(result, "Не удалось снять роль.");

        _logger.LogInformation("Role {Role} removed from user {TargetUserId} by {AdminUserId}",
            role, userId, _currentUser.Principal.GetUserId());
        return await ToDtoAsync(user, ct);
    }

    public async Task<UserDto> LinkStudentAsync(string userId, int studentId, CancellationToken ct = default)
    {
        var user = await FindUserAsync(userId);
        var student = await _db.Students.FirstOrDefaultAsync(s => s.Id == studentId, ct)
                      ?? throw new NotFoundException($"Студент {studentId} не найден.");

        if (student.UserId is not null && student.UserId != userId)
            throw new ConflictException("Профиль студента уже связан с другой учётной записью.");
        if (await _db.Students.AnyAsync(s => s.UserId == userId && s.Id != studentId, ct))
            throw new ConflictException("Учётная запись уже связана с другим профилем студента.");

        student.UserId = userId;
        await _db.SaveChangesAsync(ct);

        if (!await _userManager.IsInRoleAsync(user, Roles.Student))
            await _userManager.AddToRoleAsync(user, Roles.Student);

        return await ToDtoAsync(user, ct);
    }

    public async Task<UserDto> LinkTeacherAsync(string userId, int teacherId, CancellationToken ct = default)
    {
        var user = await FindUserAsync(userId);
        var teacher = await _db.Teachers.FirstOrDefaultAsync(t => t.Id == teacherId, ct)
                      ?? throw new NotFoundException($"Преподаватель {teacherId} не найден.");

        if (teacher.UserId is not null && teacher.UserId != userId)
            throw new ConflictException("Профиль преподавателя уже связан с другой учётной записью.");
        if (await _db.Teachers.AnyAsync(t => t.UserId == userId && t.Id != teacherId, ct))
            throw new ConflictException("Учётная запись уже связана с другим профилем преподавателя.");

        teacher.UserId = userId;
        await _db.SaveChangesAsync(ct);

        if (!await _userManager.IsInRoleAsync(user, Roles.Teacher))
            await _userManager.AddToRoleAsync(user, Roles.Teacher);

        return await ToDtoAsync(user, ct);
    }

    public async Task<UserDto> UnlockAsync(string userId, CancellationToken ct = default)
    {
        var user = await FindUserAsync(userId);
        await _userManager.SetLockoutEndDateAsync(user, null);
        await _userManager.ResetAccessFailedCountAsync(user);
        return await ToDtoAsync(user, ct);
    }

    private async Task<ApplicationUser> FindUserAsync(string userId) =>
        await _userManager.FindByIdAsync(userId)
        ?? throw new NotFoundException($"Пользователь {userId} не найден.");

    private async Task<UserDto> ToDtoAsync(ApplicationUser user, CancellationToken ct) => new UserDto
    {
        Id = user.Id,
        UserName = user.UserName ?? string.Empty,
        Email = user.Email,
        Roles = (await _userManager.GetRolesAsync(user)).ToList(),
        StudentId = await _db.Students.AsNoTracking()
            .Where(s => s.UserId == user.Id).Select(s => (int?)s.Id).FirstOrDefaultAsync(ct),
        TeacherId = await _db.Teachers.AsNoTracking()
            .Where(t => t.UserId == user.Id).Select(t => (int?)t.Id).FirstOrDefaultAsync(ct),
        IsLockedOut = user.LockoutEnd is not null && user.LockoutEnd > DateTimeOffset.UtcNow
    };
}
