using System.Security.Claims;
using Microsoft.IdentityModel.JsonWebTokens;

namespace UniversityCourseManagement.Api.Security;

public static class Roles
{
    public const string Admin = "Admin";
    public const string Teacher = "Teacher";
    public const string Student = "Student";

    public static readonly string[] All = { Admin, Teacher, Student };
}

public static class Policies
{
    /// <summary>Только администратор.</summary>
    public const string AdminOnly = "AdminOnly";

    /// <summary>Сотрудники университета: Admin или Teacher.</summary>
    public const string Staff = "Staff";

    /// <summary>Право менять оценки (роль). Принадлежность курса проверяется отдельно.</summary>
    public const string GradeEditor = "GradeEditor";

    /// <summary>Ресурсная политика: преподаватель — владелец курса (или Admin).</summary>
    public const string CourseOwner = "CourseOwner";

    /// <summary>Ресурсная политика: студент обращается к своим данным (или Admin).</summary>
    public const string StudentDataOwner = "StudentDataOwner";

    /// <summary>Ресурсная политика: просмотр записи на курс (студент-владелец, преподаватель курса, Admin).</summary>
    public const string EnrollmentViewer = "EnrollmentViewer";
}

/// <summary>Имена claims внутри JWT.</summary>
public static class AppClaimTypes
{
    public const string UserId = JwtRegisteredClaimNames.Sub;
    public const string UserName = JwtRegisteredClaimNames.UniqueName;
    public const string Role = "role";
    public const string StudentId = "student_id";
    public const string TeacherId = "teacher_id";
}

public static class ClaimsPrincipalExtensions
{
    public static string? GetUserId(this ClaimsPrincipal user) =>
        user.FindFirstValue(AppClaimTypes.UserId);

    public static int? GetStudentId(this ClaimsPrincipal user) =>
        int.TryParse(user.FindFirstValue(AppClaimTypes.StudentId), out var id) ? id : null;

    public static int? GetTeacherId(this ClaimsPrincipal user) =>
        int.TryParse(user.FindFirstValue(AppClaimTypes.TeacherId), out var id) ? id : null;
}
