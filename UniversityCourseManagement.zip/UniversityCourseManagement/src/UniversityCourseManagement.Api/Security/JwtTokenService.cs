using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;
using UniversityCourseManagement.Api.Models;

namespace UniversityCourseManagement.Api.Security;

/// <summary>
/// Настройки JWT. Issuer/Audience/срок — в appsettings.json.
/// Key (секрет подписи) — ТОЛЬКО в User Secrets или переменной окружения Jwt__Key.
/// </summary>
public sealed class JwtOptions
{
    public const string SectionName = "Jwt";

    public string Issuer { get; set; } = string.Empty;
    public string Audience { get; set; } = string.Empty;
    public string Key { get; set; } = string.Empty;
    public int AccessTokenMinutes { get; set; } = 15;

    /// <summary>Проверка при старте: без ключа или с коротким ключом приложение не запустится.</summary>
    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(Issuer) || string.IsNullOrWhiteSpace(Audience))
            throw new InvalidOperationException("Jwt:Issuer и Jwt:Audience должны быть заданы в конфигурации.");

        if (string.IsNullOrWhiteSpace(Key) || Encoding.UTF8.GetByteCount(Key) < 32)
            throw new InvalidOperationException(
                "Jwt:Key не задан или короче 32 байт. Задайте его через " +
                "'dotnet user-secrets set \"Jwt:Key\" \"<секрет>\"' или переменную окружения Jwt__Key.");

        if (AccessTokenMinutes is < 1 or > 120)
            throw new InvalidOperationException("Jwt:AccessTokenMinutes должен быть от 1 до 120 минут.");
    }

    public SymmetricSecurityKey GetSigningKey() => new(Encoding.UTF8.GetBytes(Key));
}

public sealed record AccessTokenResult(string Token, DateTime ExpiresAtUtc);

public interface ITokenService
{
    AccessTokenResult CreateAccessToken(ApplicationUser user, IEnumerable<string> roles, IEnumerable<Claim> profileClaims);
}

public sealed class JwtTokenService : ITokenService
{
    private readonly JwtOptions _options;

    public JwtTokenService(IOptions<JwtOptions> options)
    {
        _options = options.Value;
    }

    public AccessTokenResult CreateAccessToken(
        ApplicationUser user, IEnumerable<string> roles, IEnumerable<Claim> profileClaims)
    {
        var now = DateTime.UtcNow;
        var expires = now.AddMinutes(_options.AccessTokenMinutes);

        var claims = new List<Claim>
        {
            new(AppClaimTypes.UserId, user.Id),                       // идентификатор пользователя
            new(AppClaimTypes.UserName, user.UserName ?? string.Empty), // имя пользователя
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };
        claims.AddRange(roles.Select(r => new Claim(AppClaimTypes.Role, r))); // роли
        claims.AddRange(profileClaims);                                        // student_id / teacher_id

        var descriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(claims),
            Issuer = _options.Issuer,
            Audience = _options.Audience,
            IssuedAt = now,
            NotBefore = now,
            Expires = expires,
            SigningCredentials = new SigningCredentials(_options.GetSigningKey(), SecurityAlgorithms.HmacSha256)
        };

        var token = new JsonWebTokenHandler().CreateToken(descriptor);
        return new AccessTokenResult(token, expires);
    }
}
