using Microsoft.AspNetCore.Authorization;
using UniversityCourseManagement.Api.Models;

namespace UniversityCourseManagement.Api.Security;

// ---------------------------------------------------------------------------
// Ресурсная авторизация. Проверка роли отвечает на вопрос «КТО ты?»,
// а эти обработчики — «ТВОЙ ли это ресурс?». Например, роль Teacher есть
// у всех преподавателей, но менять оценки можно только по своим курсам.
// ---------------------------------------------------------------------------

public sealed class CourseOwnerRequirement : IAuthorizationRequirement { }

public sealed class StudentDataOwnerRequirement : IAuthorizationRequirement { }

public sealed class EnrollmentViewerRequirement : IAuthorizationRequirement { }

/// <summary>Ресурс «данные конкретного студента» (оценки, записи).</summary>
public sealed record StudentResource(int StudentId);

/// <summary>Admin или преподаватель, который ведёт этот курс.</summary>
public sealed class CourseOwnerHandler : AuthorizationHandler<CourseOwnerRequirement, Course>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context, CourseOwnerRequirement requirement, Course course)
    {
        var user = context.User;
        if (user.IsInRole(Roles.Admin))
        {
            context.Succeed(requirement);
        }
        else if (user.IsInRole(Roles.Teacher)
                 && course.TeacherId is not null
                 && user.GetTeacherId() == course.TeacherId)
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}

/// <summary>Admin или сам студент, чьи данные запрашиваются.</summary>
public sealed class StudentDataOwnerHandler : AuthorizationHandler<StudentDataOwnerRequirement, StudentResource>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context, StudentDataOwnerRequirement requirement, StudentResource resource)
    {
        var user = context.User;
        if (user.IsInRole(Roles.Admin)
            || (user.IsInRole(Roles.Student) && user.GetStudentId() == resource.StudentId))
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}

/// <summary>Admin, студент-владелец записи или преподаватель курса. Enrollment.Course должен быть загружен.</summary>
public sealed class EnrollmentViewerHandler : AuthorizationHandler<EnrollmentViewerRequirement, Enrollment>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context, EnrollmentViewerRequirement requirement, Enrollment enrollment)
    {
        var user = context.User;
        if (user.IsInRole(Roles.Admin)
            || (user.IsInRole(Roles.Student) && user.GetStudentId() == enrollment.StudentId)
            || (user.IsInRole(Roles.Teacher) && enrollment.Course?.TeacherId is not null
                && user.GetTeacherId() == enrollment.Course.TeacherId))
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}
