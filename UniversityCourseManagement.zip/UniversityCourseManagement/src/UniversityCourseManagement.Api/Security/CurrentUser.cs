using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using UniversityCourseManagement.Api.Common;

namespace UniversityCourseManagement.Api.Security;

/// <summary>
/// Доступ к текущему пользователю и ресурсной авторизации из сервисного слоя.
/// Проверки прав выполняются на сервере независимо от клиента.
/// </summary>
public interface ICurrentUser
{
    ClaimsPrincipal Principal { get; }
    bool IsInRole(string role);

    /// <summary>Проверяет ресурсную политику; при отказе бросает ForbiddenAccessException (403).</summary>
    Task EnsureAuthorizedAsync(object resource, string policy, string? message = null);
}

public sealed class CurrentUser : ICurrentUser
{
    private readonly IHttpContextAccessor _accessor;
    private readonly IAuthorizationService _authorization;

    public CurrentUser(IHttpContextAccessor accessor, IAuthorizationService authorization)
    {
        _accessor = accessor;
        _authorization = authorization;
    }

    public ClaimsPrincipal Principal =>
        _accessor.HttpContext?.User ?? new ClaimsPrincipal(new ClaimsIdentity());

    public bool IsInRole(string role) => Principal.IsInRole(role);

    public async Task EnsureAuthorizedAsync(object resource, string policy, string? message = null)
    {
        if (Principal.Identity?.IsAuthenticated != true)
            throw new UnauthorizedException("Требуется аутентификация.");

        var result = await _authorization.AuthorizeAsync(Principal, resource, policy);
        if (!result.Succeeded)
            throw new ForbiddenAccessException(message ?? "Нет доступа к этому ресурсу.");
    }
}
