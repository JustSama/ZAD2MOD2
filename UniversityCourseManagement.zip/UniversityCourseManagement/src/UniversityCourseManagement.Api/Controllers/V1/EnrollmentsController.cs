using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Security;
using UniversityCourseManagement.Api.Services;

namespace UniversityCourseManagement.Api.Controllers.V1;

/// <summary>Записи на курсы и оценки.</summary>
[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/enrollments")]
[Authorize]
[Produces("application/json")]
public class EnrollmentsController : ControllerBase
{
    private readonly IEnrollmentService _enrollments;

    public EnrollmentsController(IEnrollmentService enrollments)
    {
        _enrollments = enrollments;
    }

    [HttpGet]
    [Authorize(Policy = Policies.AdminOnly)]
    public async Task<ActionResult<IReadOnlyList<EnrollmentDto>>> GetAll(CancellationToken ct) =>
        Ok(await _enrollments.GetAllAsync(ct));

    /// <summary>Свои записи и оценки (для студента).</summary>
    [HttpGet("my")]
    [Authorize(Roles = Roles.Student)]
    public async Task<ActionResult<IReadOnlyList<EnrollmentDto>>> GetMy(CancellationToken ct) =>
        Ok(await _enrollments.GetMyAsync(ct));

    /// <summary>Запись по Id: Admin, студент-владелец или преподаватель курса.</summary>
    [HttpGet("{id:int}")]
    public async Task<ActionResult<EnrollmentDto>> GetById(int id, CancellationToken ct) =>
        Ok(await _enrollments.GetByIdAsync(id, ct));

    /// <summary>Записать студента на курс: Admin — любого, Student — только себя.</summary>
    [HttpPost]
    [Authorize(Roles = Roles.Admin + "," + Roles.Student)]
    public async Task<ActionResult<EnrollmentDto>> Create(CreateEnrollmentDto dto, CancellationToken ct)
    {
        var created = await _enrollments.CreateAsync(dto, ct);
        return CreatedAtAction(nameof(GetById), new { id = created.Id, version = "1" }, created);
    }

    /// <summary>
    /// Изменить оценку. Роль: Teacher/Admin (атрибут) + принадлежность курса преподавателю (сервис).
    /// Чужой курс → 403 Forbidden.
    /// </summary>
    [HttpPut("{id:int}/grade")]
    [Authorize(Policy = Policies.GradeEditor)]
    [ProducesResponseType(typeof(EnrollmentDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<EnrollmentDto>> UpdateGrade(int id, UpdateGradeDto dto, CancellationToken ct) =>
        Ok(await _enrollments.UpdateGradeAsync(id, dto.Grade!.Value, ct));

    [HttpDelete("{id:int}")]
    [Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await _enrollments.DeleteAsync(id, ct);
        return NoContent();
    }
}
