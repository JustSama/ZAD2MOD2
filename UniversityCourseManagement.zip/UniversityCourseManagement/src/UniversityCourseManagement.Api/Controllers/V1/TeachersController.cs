using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Security;
using UniversityCourseManagement.Api.Services;

namespace UniversityCourseManagement.Api.Controllers.V1;

/// <summary>Преподаватели. Чтение публичное, изменение — только Admin.</summary>
[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/teachers")]
[Authorize(Policy = Policies.AdminOnly)]
[Produces("application/json")]
public class TeachersController : ControllerBase
{
    private readonly ITeacherService _teachers;

    public TeachersController(ITeacherService teachers)
    {
        _teachers = teachers;
    }

    [HttpGet]
    [AllowAnonymous]
    public async Task<ActionResult<IReadOnlyList<TeacherDto>>> GetAll(CancellationToken ct) =>
        Ok(await _teachers.GetAllAsync(ct));

    [HttpGet("{id:int}")]
    [AllowAnonymous]
    public async Task<ActionResult<TeacherDto>> GetById(int id, CancellationToken ct) =>
        Ok(await _teachers.GetByIdAsync(id, ct));

    [HttpPost]
    public async Task<ActionResult<TeacherDto>> Create(SaveTeacherDto dto, CancellationToken ct)
    {
        var created = await _teachers.CreateAsync(dto, ct);
        return CreatedAtAction(nameof(GetById), new { id = created.Id, version = "1" }, created);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, SaveTeacherDto dto, CancellationToken ct)
    {
        await _teachers.UpdateAsync(id, dto, ct);
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await _teachers.DeleteAsync(id, ct);
        return NoContent();
    }
}
