using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Security;
using UniversityCourseManagement.Api.Services;

namespace UniversityCourseManagement.Api.Controllers.V1;

/// <summary>Студенты. Персональные данные — только для аутентифицированных пользователей.</summary>
[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/students")]
[Authorize]
[Produces("application/json")]
public class StudentsController : ControllerBase
{
    private readonly IStudentService _students;

    public StudentsController(IStudentService students)
    {
        _students = students;
    }

    [HttpGet]
    [Authorize(Policy = Policies.Staff)]
    public async Task<ActionResult<IReadOnlyList<StudentDto>>> GetAll(CancellationToken ct) =>
        Ok(await _students.GetAllAsync(ct));

    /// <summary>Admin/Teacher — любой студент; Student — только свой профиль.</summary>
    [HttpGet("{id:int}")]
    public async Task<ActionResult<StudentDto>> GetById(int id, CancellationToken ct) =>
        Ok(await _students.GetByIdAsync(id, ct));

    /// <summary>Оценки студента. Студент — только свои, иначе 403.</summary>
    [HttpGet("{id:int}/enrollments")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<IReadOnlyList<EnrollmentDto>>> GetEnrollments(int id, CancellationToken ct) =>
        Ok(await _students.GetEnrollmentsAsync(id, ct));

    [HttpPost]
    [Authorize(Policy = Policies.AdminOnly)]
    public async Task<ActionResult<StudentDto>> Create(SaveStudentDto dto, CancellationToken ct)
    {
        var created = await _students.CreateAsync(dto, ct);
        return CreatedAtAction(nameof(GetById), new { id = created.Id, version = "1" }, created);
    }

    [HttpPut("{id:int}")]
    [Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> Update(int id, SaveStudentDto dto, CancellationToken ct)
    {
        await _students.UpdateAsync(id, dto, ct);
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    [Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await _students.DeleteAsync(id, ct);
        return NoContent();
    }
}
