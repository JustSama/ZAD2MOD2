using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Security;
using UniversityCourseManagement.Api.Services;

namespace UniversityCourseManagement.Api.Controllers.V1;

/// <summary>Курсы, API v1. Контракт CourseDto сохранён без изменений.</summary>
[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/courses")]
[Authorize]
[Produces("application/json")]
public class CoursesController : ControllerBase
{
    private readonly ICourseService _courses;

    public CoursesController(ICourseService courses)
    {
        _courses = courses;
    }

    /// <summary>Список курсов (доступен анонимно).</summary>
    [HttpGet]
    [AllowAnonymous]
    public async Task<ActionResult<IReadOnlyList<CourseDto>>> GetAll(CancellationToken ct) =>
        Ok(await _courses.GetAllAsync<CourseDto>(ct));

    /// <summary>Курс по Id (доступен анонимно).</summary>
    [HttpGet("{id:int}")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<CourseDto>> GetById(int id, CancellationToken ct) =>
        Ok(await _courses.GetByIdAsync<CourseDto>(id, ct));

    /// <summary>Записи и оценки по курсу — преподаватель этого курса или Admin.</summary>
    [HttpGet("{id:int}/enrollments")]
    [Authorize(Policy = Policies.Staff)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<IReadOnlyList<EnrollmentDto>>> GetEnrollments(int id, CancellationToken ct) =>
        Ok(await _courses.GetEnrollmentsAsync(id, ct));

    [HttpPost]
    [Authorize(Policy = Policies.AdminOnly)]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<CourseDto>> Create(SaveCourseDto dto, CancellationToken ct)
    {
        var created = await _courses.CreateAsync(dto, ct);
        return CreatedAtAction(nameof(GetById), new { id = created.Id, version = "1" }, created);
    }

    [HttpPut("{id:int}")]
    [Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> Update(int id, SaveCourseDto dto, CancellationToken ct)
    {
        await _courses.UpdateAsync(id, dto, ct);
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    [Authorize(Policy = Policies.AdminOnly)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await _courses.DeleteAsync(id, ct);
        return NoContent();
    }
}
