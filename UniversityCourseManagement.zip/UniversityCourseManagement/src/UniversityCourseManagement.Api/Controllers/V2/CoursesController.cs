using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Services;

namespace UniversityCourseManagement.Api.Controllers.V2;

/// <summary>
/// Курсы, API v2: расширенный контракт CourseDetailsV2Dto
/// (преподаватель + количество записанных студентов).
/// Бизнес-логика общая с v1 — ICourseService, меняется только DTO.
/// </summary>
[ApiController]
[ApiVersion("2.0")]
[Route("api/v{version:apiVersion}/courses")]
[AllowAnonymous]
[Produces("application/json")]
public class CoursesController : ControllerBase
{
    private readonly ICourseService _courses;

    public CoursesController(ICourseService courses)
    {
        _courses = courses;
    }

    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<CourseDetailsV2Dto>>> GetAll(CancellationToken ct) =>
        Ok(await _courses.GetAllAsync<CourseDetailsV2Dto>(ct));

    [HttpGet("{id:int}")]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<CourseDetailsV2Dto>> GetById(int id, CancellationToken ct) =>
        Ok(await _courses.GetByIdAsync<CourseDetailsV2Dto>(id, ct));
}
