using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Security;
using UniversityCourseManagement.Api.Services;

namespace UniversityCourseManagement.Api.Controllers;

/// <summary>
/// Управление пользователями и ролями. Весь контроллер — только Admin.
/// Student/Teacher при попытке назначить себе роль получают 403 Forbidden.
/// </summary>
[ApiController]
[ApiVersionNeutral]
[Route("api/users")]
[Authorize(Policy = Policies.AdminOnly)]
[Produces("application/json")]
public class UsersController : ControllerBase
{
    private readonly IUserManagementService _users;

    public UsersController(IUserManagementService users)
    {
        _users = users;
    }

    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<UserDto>>> GetAll(CancellationToken ct) =>
        Ok(await _users.GetUsersAsync(ct));

    [HttpGet("{userId}")]
    public async Task<ActionResult<UserDto>> Get(string userId, CancellationToken ct) =>
        Ok(await _users.GetUserAsync(userId, ct));

    /// <summary>Назначить роль пользователю.</summary>
    [HttpPost("{userId}/roles")]
    [ProducesResponseType(typeof(UserDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<UserDto>> AssignRole(string userId, AssignRoleRequest request, CancellationToken ct) =>
        Ok(await _users.AssignRoleAsync(userId, request.Role, ct));

    /// <summary>Снять роль с пользователя.</summary>
    [HttpDelete("{userId}/roles/{role}")]
    public async Task<ActionResult<UserDto>> RemoveRole(string userId, string role, CancellationToken ct) =>
        Ok(await _users.RemoveRoleAsync(userId, role, ct));

    /// <summary>Связать учётную запись с сущностью Student.</summary>
    [HttpPut("{userId}/student")]
    public async Task<ActionResult<UserDto>> LinkStudent(string userId, LinkProfileRequest request, CancellationToken ct) =>
        Ok(await _users.LinkStudentAsync(userId, request.ProfileId, ct));

    /// <summary>Связать учётную запись с сущностью Teacher.</summary>
    [HttpPut("{userId}/teacher")]
    public async Task<ActionResult<UserDto>> LinkTeacher(string userId, LinkProfileRequest request, CancellationToken ct) =>
        Ok(await _users.LinkTeacherAsync(userId, request.ProfileId, ct));

    /// <summary>Снять блокировку после неудачных попыток входа.</summary>
    [HttpPost("{userId}/unlock")]
    public async Task<ActionResult<UserDto>> Unlock(string userId, CancellationToken ct) =>
        Ok(await _users.UnlockAsync(userId, ct));
}

[ApiController]
[ApiVersionNeutral]
[Route("api/roles")]
[Authorize(Policy = Policies.AdminOnly)]
[Produces("application/json")]
public class RolesController : ControllerBase
{
    private readonly IUserManagementService _users;

    public RolesController(IUserManagementService users)
    {
        _users = users;
    }

    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<string>>> GetAll(CancellationToken ct) =>
        Ok(await _users.GetRolesAsync(ct));

    [HttpPost]
    public async Task<IActionResult> Create(CreateRoleRequest request, CancellationToken ct)
    {
        await _users.CreateRoleAsync(request.Name, ct);
        return StatusCode(StatusCodes.Status201Created);
    }
}
