using System.Reflection;
using Asp.Versioning;
using Asp.Versioning.ApiExplorer;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Swashbuckle.AspNetCore.SwaggerGen;
using UniversityCourseManagement.Api.Common;
using UniversityCourseManagement.Api.Data;
using UniversityCourseManagement.Api.Mapping;
using UniversityCourseManagement.Api.Middleware;
using UniversityCourseManagement.Api.Models;
using UniversityCourseManagement.Api.Repositories;
using UniversityCourseManagement.Api.Security;
using UniversityCourseManagement.Api.Services;
using UniversityCourseManagement.Api.Swagger;

var builder = WebApplication.CreateBuilder(args);
var config = builder.Configuration;

// ---------------------------------------------------------------- База данных
builder.Services.AddDbContext<AppDbContext>(o =>
    o.UseSqlite(config.GetConnectionString("DefaultConnection")));

// ---------------------------------------------------------------- Identity
builder.Services
    .AddIdentityCore<ApplicationUser>(o =>
    {
        // Сложность пароля
        o.Password.RequiredLength = 8;
        o.Password.RequireDigit = true;
        o.Password.RequireLowercase = true;
        o.Password.RequireUppercase = true;
        o.Password.RequireNonAlphanumeric = false;

        // Блокировка после 5 неудачных попыток на 5 минут
        o.Lockout.AllowedForNewUsers = true;
        o.Lockout.MaxFailedAccessAttempts = 5;
        o.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(5);

        // Уникальность имени пользователя Identity проверяет всегда; email — тоже уникален
        o.User.RequireUniqueEmail = true;
    })
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<AppDbContext>()
    .AddSignInManager()
    .AddDefaultTokenProviders();

// ---------------------------------------------------------------- JWT
var jwtOptions = config.GetSection(JwtOptions.SectionName).Get<JwtOptions>() ?? new JwtOptions();
jwtOptions.Validate(); // fail fast: без ключа API не стартует
builder.Services.Configure<JwtOptions>(config.GetSection(JwtOptions.SectionName));

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(o =>
    {
        o.MapInboundClaims = false; // claims в токене = claims в User (sub, unique_name, role)
        o.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwtOptions.Issuer,
            ValidateAudience = true,
            ValidAudience = jwtOptions.Audience,
            ValidateLifetime = true,
            RequireExpirationTime = true,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = jwtOptions.GetSigningKey(),
            ValidAlgorithms = new[] { SecurityAlgorithms.HmacSha256 },
            ClockSkew = TimeSpan.Zero, // просроченный токен отклоняется сразу
            NameClaimType = AppClaimTypes.UserName,
            RoleClaimType = AppClaimTypes.Role
        };

        // 401/403 в том же формате ProblemDetails, что и остальные ошибки
        o.Events = new JwtBearerEvents
        {
            OnChallenge = async ctx =>
            {
                ctx.HandleResponse();
                var detail = ctx.AuthenticateFailure switch
                {
                    SecurityTokenExpiredException => "Срок действия токена истёк.",
                    SecurityTokenInvalidSignatureException => "Подпись токена недействительна.",
                    null => "Требуется аутентификация: передайте заголовок Authorization: Bearer <token>.",
                    _ => "Токен недействителен."
                };
                ctx.Response.Headers.WWWAuthenticate = ctx.AuthenticateFailure is null
                    ? "Bearer"
                    : "Bearer error=\"invalid_token\"";
                await ProblemDetailsWriter.WriteAsync(ctx.HttpContext,
                    StatusCodes.Status401Unauthorized, "Unauthorized", detail);
            },
            OnForbidden = ctx => ProblemDetailsWriter.WriteAsync(ctx.HttpContext,
                StatusCodes.Status403Forbidden, "Forbidden",
                "Недостаточно прав для выполнения операции.")
        };
    });

// ---------------------------------------------------------------- Авторизация: роли + политики
builder.Services.AddAuthorization(o =>
{
    o.AddPolicy(Policies.AdminOnly, p => p.RequireRole(Roles.Admin));
    o.AddPolicy(Policies.Staff, p => p.RequireRole(Roles.Admin, Roles.Teacher));
    o.AddPolicy(Policies.GradeEditor, p => p.RequireRole(Roles.Admin, Roles.Teacher));
    o.AddPolicy(Policies.CourseOwner, p => p.AddRequirements(new CourseOwnerRequirement()));
    o.AddPolicy(Policies.StudentDataOwner, p => p.AddRequirements(new StudentDataOwnerRequirement()));
    o.AddPolicy(Policies.EnrollmentViewer, p => p.AddRequirements(new EnrollmentViewerRequirement()));
});
builder.Services.AddSingleton<IAuthorizationHandler, CourseOwnerHandler>();
builder.Services.AddSingleton<IAuthorizationHandler, StudentDataOwnerHandler>();
builder.Services.AddSingleton<IAuthorizationHandler, EnrollmentViewerHandler>();

// ---------------------------------------------------------------- CORS: два разрешённых клиента
const string CorsPolicyName = "UniversityClients";
var allowedOrigins = config.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? Array.Empty<string>();
builder.Services.AddCors(o => o.AddPolicy(CorsPolicyName, p => p
    .WithOrigins(allowedOrigins)
    .WithMethods("GET", "POST", "PUT", "DELETE")
    .WithHeaders("Authorization", "Content-Type", "Accept")
    .WithExposedHeaders("api-supported-versions", "api-deprecated-versions")));

// ---------------------------------------------------------------- Версионирование API
builder.Services
    .AddApiVersioning(o =>
    {
        o.DefaultApiVersion = new ApiVersion(1, 0);
        o.AssumeDefaultVersionWhenUnspecified = true;
        o.ReportApiVersions = true; // заголовок api-supported-versions
        o.ApiVersionReader = new UrlSegmentApiVersionReader();
    })
    .AddMvc()
    .AddApiExplorer(o =>
    {
        o.GroupNameFormat = "'v'VVV";   // v1, v2
        o.SubstituteApiVersionInUrl = true;
    });

// ---------------------------------------------------------------- MVC, Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddTransient<IConfigureOptions<SwaggerGenOptions>, ConfigureSwaggerOptions>();
builder.Services.AddSwaggerGen(o =>
{
    var xml = Path.Combine(AppContext.BaseDirectory, $"{Assembly.GetExecutingAssembly().GetName().Name}.xml");
    if (File.Exists(xml)) o.IncludeXmlComments(xml);
});

// ---------------------------------------------------------------- Прикладные сервисы
builder.Services.AddHttpContextAccessor();
builder.Services.AddAutoMapper(typeof(MappingProfile));
builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
builder.Services.AddScoped<ICurrentUser, CurrentUser>();
builder.Services.AddScoped<ITokenService, JwtTokenService>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IUserManagementService, UserManagementService>();
builder.Services.AddScoped<IStudentService, StudentService>();
builder.Services.AddScoped<ITeacherService, TeacherService>();
builder.Services.AddScoped<ICourseService, CourseService>();
builder.Services.AddScoped<IEnrollmentService, EnrollmentService>();

var app = builder.Build();

// ---------------------------------------------------------------- Миграции + тестовые данные
var seedOnly = args.Contains("--seed");
if (seedOnly || config.GetValue<bool>("Seed:Enabled"))
{
    using var scope = app.Services.CreateScope();
    var logger = scope.ServiceProvider.GetRequiredService<ILoggerFactory>().CreateLogger("DbSeeder");
    await DbSeeder.SeedAsync(scope.ServiceProvider, config, logger);
    if (seedOnly)
    {
        logger.LogInformation("Seeding completed");
        return;
    }
}

// ---------------------------------------------------------------- Конвейер (порядок важен!)
app.UseMiddleware<ExceptionHandlingMiddleware>();   // 1. перехват ошибок всего конвейера

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(o =>
    {
        var provider = app.Services.GetRequiredService<IApiVersionDescriptionProvider>();
        foreach (var d in provider.ApiVersionDescriptions.Reverse())
            o.SwaggerEndpoint($"/swagger/{d.GroupName}/swagger.json", d.GroupName.ToUpperInvariant());
    });
}

app.UseHttpsRedirection();
app.UseRouting();                 // 2. выбор endpoint (нужен для авторизации по атрибутам)
app.UseCors(CorsPolicyName);      // 3. CORS — до аутентификации (preflight OPTIONS без токена)
app.UseAuthentication();          // 4. КТО ты: JWT -> HttpContext.User
app.UseAuthorization();           // 5. ЧТО тебе можно: [Authorize], роли, политики
app.MapControllers();             // 6. контроллер

app.Run();

// для интеграционных тестов (WebApplicationFactory)
public partial class Program { }
