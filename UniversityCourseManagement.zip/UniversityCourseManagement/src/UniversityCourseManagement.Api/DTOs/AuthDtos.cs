using System.ComponentModel.DataAnnotations;

namespace UniversityCourseManagement.Api.DTOs;

/// <summary>
/// Регистрация. Поля роли здесь НЕТ намеренно: клиент не может запросить себе Admin.
/// </summary>
public class RegisterRequest
{
    [Required, StringLength(50, MinimumLength = 3)]
    [RegularExpression(@"^[a-zA-Z0-9._-]+$", ErrorMessage = "Допустимы латинские буквы, цифры, '.', '_' и '-'.")]
    public string UserName { get; set; } = string.Empty;

    [Required, EmailAddress, StringLength(256)]
    public string Email { get; set; } = string.Empty;

    [Required, StringLength(100, MinimumLength = 8)]
    public string Password { get; set; } = string.Empty;
}

public class LoginRequest
{
    [Required]
    public string UserName { get; set; } = string.Empty;

    [Required]
    public string Password { get; set; } = string.Empty;
}

public class LoginResponse
{
    public string AccessToken { get; set; } = string.Empty;
    public string TokenType { get; set; } = "Bearer";
    public DateTime ExpiresAtUtc { get; set; }
    public string UserName { get; set; } = string.Empty;
    public IReadOnlyList<string> Roles { get; set; } = Array.Empty<string>();
}

/// <summary>Безопасное представление пользователя: без PasswordHash, SecurityStamp и т.п.</summary>
public class UserDto
{
    public string Id { get; set; } = string.Empty;
    public string UserName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public IReadOnlyList<string> Roles { get; set; } = Array.Empty<string>();
    public int? StudentId { get; set; }
    public int? TeacherId { get; set; }
    public bool IsLockedOut { get; set; }
}

public class AssignRoleRequest
{
    [Required]
    public string Role { get; set; } = string.Empty;
}

public class CreateRoleRequest
{
    [Required, StringLength(50, MinimumLength = 2)]
    public string Name { get; set; } = string.Empty;
}

public class LinkProfileRequest
{
    [Range(1, int.MaxValue)]
    public int ProfileId { get; set; }
}
