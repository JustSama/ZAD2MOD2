using System.ComponentModel.DataAnnotations;

namespace UniversityCourseManagement.Api.DTOs;

// ============================ Students ============================

/// <summary>Студент (без UserId и других служебных данных).</summary>
public class StudentDto
{
    public int Id { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public int EnrollmentYear { get; set; }
}

public class SaveStudentDto
{
    [Required, StringLength(100, MinimumLength = 1)]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(100, MinimumLength = 1)]
    public string LastName { get; set; } = string.Empty;

    [Required, EmailAddress, StringLength(200)]
    public string Email { get; set; } = string.Empty;

    [Range(2000, 2100)]
    public int EnrollmentYear { get; set; }
}

// ============================ Teachers ============================

public class TeacherDto
{
    public int Id { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
}

public class SaveTeacherDto
{
    [Required, StringLength(100, MinimumLength = 1)]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(100, MinimumLength = 1)]
    public string LastName { get; set; } = string.Empty;

    [Required, EmailAddress, StringLength(200)]
    public string Email { get; set; } = string.Empty;

    [Required, StringLength(100, MinimumLength = 1)]
    public string Department { get; set; } = string.Empty;
}

// ============================ Courses ============================

/// <summary>Контракт курса API v1 (не меняется, чтобы не ломать клиентов v1).</summary>
public class CourseDto
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int Credits { get; set; }
    public int? TeacherId { get; set; }
}

/// <summary>Контракт курса API v2: + сведения о преподавателе и число записанных студентов.</summary>
public class CourseDetailsV2Dto
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int Credits { get; set; }
    public CourseTeacherV2Dto? Teacher { get; set; }
    public int EnrolledStudentsCount { get; set; }
}

public class CourseTeacherV2Dto
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
}

public class SaveCourseDto
{
    [Required, StringLength(20, MinimumLength = 2)]
    public string Code { get; set; } = string.Empty;

    [Required, StringLength(200, MinimumLength = 2)]
    public string Title { get; set; } = string.Empty;

    [StringLength(1000)]
    public string? Description { get; set; }

    [Range(1, 30)]
    public int Credits { get; set; }

    public int? TeacherId { get; set; }
}

// ============================ Enrollments ============================

public class EnrollmentDto
{
    public int Id { get; set; }
    public int StudentId { get; set; }
    public string StudentName { get; set; } = string.Empty;
    public int CourseId { get; set; }
    public string CourseCode { get; set; } = string.Empty;
    public string CourseTitle { get; set; } = string.Empty;
    public DateTime EnrolledAt { get; set; }
    public int? Grade { get; set; }
}

public class CreateEnrollmentDto
{
    [Range(1, int.MaxValue)]
    public int StudentId { get; set; }

    [Range(1, int.MaxValue)]
    public int CourseId { get; set; }
}

public class UpdateGradeDto
{
    [Required, Range(0, 100)]
    public int? Grade { get; set; }
}
