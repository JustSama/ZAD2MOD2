using AutoMapper;
using UniversityCourseManagement.Api.DTOs;
using UniversityCourseManagement.Api.Models;

namespace UniversityCourseManagement.Api.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<Student, StudentDto>();
        CreateMap<SaveStudentDto, Student>()
            .ForMember(d => d.Id, o => o.Ignore())
            .ForMember(d => d.UserId, o => o.Ignore())
            .ForMember(d => d.Enrollments, o => o.Ignore());

        CreateMap<Teacher, TeacherDto>();
        CreateMap<SaveTeacherDto, Teacher>()
            .ForMember(d => d.Id, o => o.Ignore())
            .ForMember(d => d.UserId, o => o.Ignore())
            .ForMember(d => d.Courses, o => o.Ignore());

        // v1
        CreateMap<Course, CourseDto>();

        // v2 — отдельный контракт
        CreateMap<Teacher, CourseTeacherV2Dto>()
            .ForMember(d => d.FullName, o => o.MapFrom(t => t.FirstName + " " + t.LastName));
        CreateMap<Course, CourseDetailsV2Dto>()
            .ForMember(d => d.EnrolledStudentsCount, o => o.MapFrom(c => c.Enrollments.Count));

        CreateMap<SaveCourseDto, Course>()
            .ForMember(d => d.Id, o => o.Ignore())
            .ForMember(d => d.Teacher, o => o.Ignore())
            .ForMember(d => d.Enrollments, o => o.Ignore());

        CreateMap<Enrollment, EnrollmentDto>()
            .ForMember(d => d.StudentName, o => o.MapFrom(e => e.Student.FirstName + " " + e.Student.LastName))
            .ForMember(d => d.CourseCode, o => o.MapFrom(e => e.Course.Code))
            .ForMember(d => d.CourseTitle, o => o.MapFrom(e => e.Course.Title));
    }
}
