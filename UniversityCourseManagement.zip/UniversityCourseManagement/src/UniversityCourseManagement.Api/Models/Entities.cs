using Microsoft.AspNetCore.Identity;

namespace UniversityCourseManagement.Api.Models;

/// <summary>Учётная запись пользователя (ASP.NET Core Identity).</summary>
public class ApplicationUser : IdentityUser
{
}

public class Student
{
    public int Id { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public int EnrollmentYear { get; set; }

    /// <summary>Связь с учётной записью Identity (может отсутствовать).</summary>
    public string? UserId { get; set; }

    public ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
}

public class Teacher
{
    public int Id { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;

    /// <summary>Связь с учётной записью Identity (может отсутствовать).</summary>
    public string? UserId { get; set; }

    public ICollection<Course> Courses { get; set; } = new List<Course>();
}

public class Course
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int Credits { get; set; }

    public int? TeacherId { get; set; }
    public Teacher? Teacher { get; set; }

    public ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
}

public class Enrollment
{
    public int Id { get; set; }

    public int StudentId { get; set; }
    public Student Student { get; set; } = null!;

    public int CourseId { get; set; }
    public Course Course { get; set; } = null!;

    public DateTime EnrolledAt { get; set; }

    /// <summary>Оценка 0–100, null — ещё не выставлена.</summary>
    public int? Grade { get; set; }
}
