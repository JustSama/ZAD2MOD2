using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using UniversityCourseManagement.Api.Models;
using UniversityCourseManagement.Api.Security;

namespace UniversityCourseManagement.Api.Data;

/// <summary>
/// Применяет миграции и создаёт тестовые данные: роли, пользователей,
/// преподавателей, студентов, курсы и записи. Идемпотентен — повторный запуск ничего не дублирует.
/// Запуск: автоматически при старте (Seed:Enabled=true) или командой `dotnet run -- --seed`.
/// </summary>
public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services, IConfiguration configuration, ILogger logger)
    {
        var db = services.GetRequiredService<AppDbContext>();
        await db.Database.MigrateAsync();

        // 1. Роли
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        foreach (var role in Roles.All)
        {
            if (!await roleManager.RoleExistsAsync(role))
            {
                await roleManager.CreateAsync(new IdentityRole(role));
                logger.LogInformation("Seed: role {Role} created", role);
            }
        }

        // 2. Доменные данные
        if (!await db.Teachers.AnyAsync())
        {
            var t1 = new Teacher { FirstName = "Ерлан", LastName = "Ахметов", Email = "e.akhmetov@uni.kz", Department = "Программная инженерия" };
            var t2 = new Teacher { FirstName = "Айгерим", LastName = "Садыкова", Email = "a.sadykova@uni.kz", Department = "Информационные системы" };
            db.Teachers.AddRange(t1, t2);

            var s1 = new Student { FirstName = "Даурен", LastName = "Алиев", Email = "d.aliyev@stud.uni.kz", EnrollmentYear = 2023 };
            var s2 = new Student { FirstName = "Мадина", LastName = "Серикова", Email = "m.serikova@stud.uni.kz", EnrollmentYear = 2023 };
            var s3 = new Student { FirstName = "Тимур", LastName = "Жумабаев", Email = "t.zhumabayev@stud.uni.kz", EnrollmentYear = 2024 };
            db.Students.AddRange(s1, s2, s3);

            var c1 = new Course { Code = "CSE5032", Title = "Разработка веб-сервисов", Credits = 5, Teacher = t1, Description = "ASP.NET Core Web API, REST, безопасность" };
            var c2 = new Course { Code = "CSE3011", Title = "Базы данных", Credits = 5, Teacher = t2, Description = "Реляционная модель, SQL, нормализация" };
            var c3 = new Course { Code = "CSE2104", Title = "Алгоритмы и структуры данных", Credits = 6, Teacher = t1, Description = "Сложность алгоритмов, сортировки, графы" };
            db.Courses.AddRange(c1, c2, c3);
            await db.SaveChangesAsync();

            var now = DateTime.UtcNow;
            // Порядок важен для демонстрации: Id записей 1..5
            db.Enrollments.AddRange(
                new Enrollment { Student = s1, Course = c1, EnrolledAt = now, Grade = 85 }, // 1 — курс Ахметова
                new Enrollment { Student = s1, Course = c2, EnrolledAt = now, Grade = 90 }, // 2 — курс Садыковой
                new Enrollment { Student = s2, Course = c1, EnrolledAt = now, Grade = 78 }, // 3 — курс Ахметова
                new Enrollment { Student = s2, Course = c3, EnrolledAt = now },             // 4 — курс Ахметова
                new Enrollment { Student = s3, Course = c2, EnrolledAt = now, Grade = 88 }  // 5 — курс Садыковой
            );
            await db.SaveChangesAsync();
            logger.LogInformation("Seed: university data created");
        }

        // 3. Тестовые пользователи (пароль берётся из конфигурации, не из кода)
        var password = configuration["Seed:DefaultPassword"];
        if (string.IsNullOrWhiteSpace(password))
        {
            logger.LogWarning("Seed: Seed:DefaultPassword is not configured — test users are skipped");
            return;
        }

        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();

        await EnsureUserAsync(userManager, logger, "admin", "admin@uni.kz", password, Roles.Admin);

        var teacher1 = await EnsureUserAsync(userManager, logger, "teacher.akhmetov", "e.akhmetov@uni.kz", password, Roles.Teacher);
        var teacher2 = await EnsureUserAsync(userManager, logger, "teacher.sadykova", "a.sadykova@uni.kz", password, Roles.Teacher);
        var student1 = await EnsureUserAsync(userManager, logger, "student.aliyev", "d.aliyev@stud.uni.kz", password, Roles.Student);
        var student2 = await EnsureUserAsync(userManager, logger, "student.serikova", "m.serikova@stud.uni.kz", password, Roles.Student);

        // Связь учётных записей с сущностями Teacher / Student
        await LinkTeacherAsync(db, "e.akhmetov@uni.kz", teacher1);
        await LinkTeacherAsync(db, "a.sadykova@uni.kz", teacher2);
        await LinkStudentAsync(db, "d.aliyev@stud.uni.kz", student1);
        await LinkStudentAsync(db, "m.serikova@stud.uni.kz", student2);
        await db.SaveChangesAsync();
    }

    private static async Task<ApplicationUser> EnsureUserAsync(
        UserManager<ApplicationUser> userManager, ILogger logger,
        string userName, string email, string password, string role)
    {
        var user = await userManager.FindByNameAsync(userName);
        if (user is null)
        {
            user = new ApplicationUser { UserName = userName, Email = email, EmailConfirmed = true };
            var result = await userManager.CreateAsync(user, password);
            if (!result.Succeeded)
                throw new InvalidOperationException(
                    $"Seed: cannot create {userName}: {string.Join("; ", result.Errors.Select(e => e.Description))}");
            logger.LogInformation("Seed: user {UserName} created", userName);
        }

        if (!await userManager.IsInRoleAsync(user, role))
            await userManager.AddToRoleAsync(user, role);

        return user;
    }

    private static async Task LinkTeacherAsync(AppDbContext db, string email, ApplicationUser user)
    {
        var teacher = await db.Teachers.FirstOrDefaultAsync(t => t.Email == email);
        if (teacher is not null && teacher.UserId is null)
            teacher.UserId = user.Id;
    }

    private static async Task LinkStudentAsync(AppDbContext db, string email, ApplicationUser user)
    {
        var student = await db.Students.FirstOrDefaultAsync(s => s.Email == email);
        if (student is not null && student.UserId is null)
            student.UserId = user.Id;
    }
}
