using Microsoft.EntityFrameworkCore;
using UniversityCourseManagement.Api.Common;

namespace UniversityCourseManagement.Api.Middleware;

/// <summary>
/// Глобальная обработка ошибок. Переводит исключения приложения в ProblemDetails.
/// В лог пишутся только метод, путь и тип ошибки — без тела запроса,
/// заголовков, паролей и JWT.
/// </summary>
public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (AppException ex) when (!context.Response.HasStarted)
        {
            _logger.LogInformation("{Method} {Path} -> {Status} ({Title})",
                context.Request.Method, context.Request.Path, ex.StatusCode, ex.Title);

            var errors = (ex as BadRequestException)?.Errors;
            await ProblemDetailsWriter.WriteAsync(context, ex.StatusCode, ex.Title, ex.Message, errors);
        }
        catch (DbUpdateException ex) when (!context.Response.HasStarted)
        {
            _logger.LogWarning(ex, "Database update failed for {Method} {Path}",
                context.Request.Method, context.Request.Path);
            await ProblemDetailsWriter.WriteAsync(context, StatusCodes.Status409Conflict, "Conflict",
                "Операция нарушает ограничения базы данных (дубликат или связанная запись).");
        }
        catch (Exception ex) when (!context.Response.HasStarted)
        {
            _logger.LogError(ex, "Unhandled exception for {Method} {Path}",
                context.Request.Method, context.Request.Path);
            await ProblemDetailsWriter.WriteAsync(context, StatusCodes.Status500InternalServerError,
                "Internal Server Error", "Произошла внутренняя ошибка сервера.");
        }
    }
}
