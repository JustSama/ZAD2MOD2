using Asp.Versioning.ApiExplorer;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace UniversityCourseManagement.Api.Swagger;

/// <summary>
/// Создаёт отдельный OpenAPI-документ для каждой версии API (v1, v2)
/// и добавляет схему безопасности JWT Bearer (кнопка Authorize в Swagger UI).
/// </summary>
public sealed class ConfigureSwaggerOptions : IConfigureOptions<SwaggerGenOptions>
{
    private readonly IApiVersionDescriptionProvider _provider;

    public ConfigureSwaggerOptions(IApiVersionDescriptionProvider provider)
    {
        _provider = provider;
    }

    public void Configure(SwaggerGenOptions options)
    {
        foreach (var description in _provider.ApiVersionDescriptions)
        {
            options.SwaggerDoc(description.GroupName, new OpenApiInfo
            {
                Title = "University Course Management API",
                Version = description.ApiVersion.ToString(),
                Description = description.ApiVersion.MajorVersion == 2
                    ? "v2: курсы с данными преподавателя и количеством записанных студентов."
                    : "v1: базовый контракт (CRUD студентов, преподавателей, курсов, записей)."
                      + (description.IsDeprecated ? " Версия устарела." : string.Empty)
            });
        }

        var bearerScheme = new OpenApiSecurityScheme
        {
            Name = "Authorization",
            Type = SecuritySchemeType.Http,
            Scheme = "bearer",
            BearerFormat = "JWT",
            In = ParameterLocation.Header,
            Description = "Вставьте JWT из POST /api/auth/login (без слова Bearer).",
            Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
        };

        options.AddSecurityDefinition("Bearer", bearerScheme);
        options.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
            { bearerScheme, Array.Empty<string>() }
        });
    }
}
