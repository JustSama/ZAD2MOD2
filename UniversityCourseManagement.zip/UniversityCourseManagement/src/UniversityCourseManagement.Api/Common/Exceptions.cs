namespace UniversityCourseManagement.Api.Common;

/// <summary>
/// Базовое исключение приложения. Обрабатывается ExceptionHandlingMiddleware
/// и превращается в ответ ProblemDetails с нужным HTTP-кодом.
/// </summary>
public abstract class AppException : Exception
{
    protected AppException(int statusCode, string title, string message) : base(message)
    {
        StatusCode = statusCode;
        Title = title;
    }

    public int StatusCode { get; }
    public string Title { get; }
}

public sealed class NotFoundException : AppException
{
    public NotFoundException(string message) : base(StatusCodes.Status404NotFound, "Not Found", message) { }
}

public sealed class ConflictException : AppException
{
    public ConflictException(string message) : base(StatusCodes.Status409Conflict, "Conflict", message) { }
}

public sealed class BadRequestException : AppException
{
    public BadRequestException(string message, IDictionary<string, string[]>? errors = null)
        : base(StatusCodes.Status400BadRequest, "Bad Request", message)
    {
        Errors = errors;
    }

    public IDictionary<string, string[]>? Errors { get; }
}

/// <summary>401 — пользователь не аутентифицирован (например, неверный логин/пароль).</summary>
public sealed class UnauthorizedException : AppException
{
    public UnauthorizedException(string message) : base(StatusCodes.Status401Unauthorized, "Unauthorized", message) { }
}

/// <summary>403 — пользователь аутентифицирован, но не имеет прав на ресурс.</summary>
public sealed class ForbiddenAccessException : AppException
{
    public ForbiddenAccessException(string message = "Недостаточно прав для выполнения операции.")
        : base(StatusCodes.Status403Forbidden, "Forbidden", message) { }
}

/// <summary>423 — учётная запись временно заблокирована после неудачных попыток входа.</summary>
public sealed class AccountLockedException : AppException
{
    public AccountLockedException(string message) : base(StatusCodes.Status423Locked, "Locked", message) { }
}
