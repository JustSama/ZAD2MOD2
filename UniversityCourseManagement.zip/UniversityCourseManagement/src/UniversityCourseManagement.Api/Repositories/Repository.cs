using Microsoft.EntityFrameworkCore;
using UniversityCourseManagement.Api.Data;

namespace UniversityCourseManagement.Api.Repositories;

public interface IRepository<T> where T : class
{
    /// <summary>Запрос для чтения (без отслеживания).</summary>
    IQueryable<T> Query();

    /// <summary>Запрос с отслеживанием изменений (для обновления).</summary>
    IQueryable<T> QueryTracked();

    Task<T?> GetByIdAsync(int id, CancellationToken ct = default);
    Task AddAsync(T entity, CancellationToken ct = default);
    void Remove(T entity);
    Task<int> SaveChangesAsync(CancellationToken ct = default);
}

public class Repository<T> : IRepository<T> where T : class
{
    protected readonly AppDbContext Db;
    protected readonly DbSet<T> Set;

    public Repository(AppDbContext db)
    {
        Db = db;
        Set = db.Set<T>();
    }

    public IQueryable<T> Query() => Set.AsNoTracking();

    public IQueryable<T> QueryTracked() => Set;

    public async Task<T?> GetByIdAsync(int id, CancellationToken ct = default) =>
        await Set.FindAsync(new object[] { id }, ct);

    public async Task AddAsync(T entity, CancellationToken ct = default) =>
        await Set.AddAsync(entity, ct);

    public void Remove(T entity) => Set.Remove(entity);

    public Task<int> SaveChangesAsync(CancellationToken ct = default) => Db.SaveChangesAsync(ct);
}
