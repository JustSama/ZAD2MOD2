namespace UniversityCourseManagement.Client.Models;

/// <summary>
/// Модель курса на клиенте. Поддерживает ответы v1 и v2:
/// поля Teacher и EnrolledStudentsCount приходят только из v2.
/// </summary>
public sealed class CourseViewModel
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int Credits { get; set; }

    // v1
    public int? TeacherId { get; set; }

    // v2
    public CourseTeacherViewModel? Teacher { get; set; }
    public int? EnrolledStudentsCount { get; set; }
}

public sealed class CourseTeacherViewModel
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
}

public sealed class CourseListPageModel
{
    public int ApiVersion { get; init; }
    public IReadOnlyList<CourseViewModel> Courses { get; init; } = Array.Empty<CourseViewModel>();
    public string? ErrorMessage { get; init; }
}

public sealed class CourseDetailsPageModel
{
    public int ApiVersion { get; init; }
    public CourseViewModel? Course { get; init; }
    public string? ErrorMessage { get; init; }
}
