using System.Net.Http.Headers;
using Microsoft.Extensions.Options;
using UniversityCourseManagement.Client.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// Адрес API — только из конфигурации (appsettings.json), не из кода
builder.Services
    .AddOptions<UniversityApiOptions>()
    .Bind(builder.Configuration.GetSection(UniversityApiOptions.SectionName))
    .Validate(o => Uri.TryCreate(o.BaseUrl, UriKind.Absolute, out _), "UniversityApi:BaseUrl must be an absolute URL")
    .ValidateOnStart();

// Типизированный HttpClient через IHttpClientFactory
builder.Services.AddHttpClient<IUniversityApiClient, UniversityApiClient>((sp, client) =>
{
    var options = sp.GetRequiredService<IOptions<UniversityApiOptions>>().Value;
    client.BaseAddress = new Uri(options.BaseUrl);
    client.Timeout = TimeSpan.FromSeconds(options.TimeoutSeconds);
    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Courses}/{action=Index}/{id?}");

app.Run();
