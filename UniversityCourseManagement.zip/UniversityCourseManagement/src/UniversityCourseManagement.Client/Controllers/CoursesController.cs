using System.Net;
using Microsoft.AspNetCore.Mvc;
using UniversityCourseManagement.Client.Models;
using UniversityCourseManagement.Client.Services;

namespace UniversityCourseManagement.Client.Controllers;

public class CoursesController : Controller
{
    private readonly IUniversityApiClient _api;

    public CoursesController(IUniversityApiClient api)
    {
        _api = api;
    }

    /// <summary>Список курсов. ?v=1 или ?v=2 — версия API.</summary>
    public async Task<IActionResult> Index(int v = 2, CancellationToken ct = default)
    {
        var result = await _api.GetCoursesAsync(v, ct);
        return View(new CourseListPageModel
        {
            ApiVersion = v == 1 ? 1 : 2,
            Courses = result.Data ?? Array.Empty<CourseViewModel>(),
            ErrorMessage = result.ErrorMessage
        });
    }

    /// <summary>Сведения о курсе.</summary>
    public async Task<IActionResult> Details(int id, int v = 2, CancellationToken ct = default)
    {
        var result = await _api.GetCourseAsync(id, v, ct);
        if (result.StatusCode == HttpStatusCode.NotFound)
            Response.StatusCode = StatusCodes.Status404NotFound;

        return View(new CourseDetailsPageModel
        {
            ApiVersion = v == 1 ? 1 : 2,
            Course = result.Data,
            ErrorMessage = result.ErrorMessage
        });
    }
}

public class HomeController : Controller
{
    public IActionResult Index() => RedirectToAction("Index", "Courses");

    public IActionResult Error() => View();
}
