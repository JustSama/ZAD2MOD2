using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using UniversityCourseManagement.Client.Models;

namespace UniversityCourseManagement.Client.Services;

public sealed class UniversityApiOptions
{
    public const string SectionName = "UniversityApi";

    public string BaseUrl { get; set; } = string.Empty;
    public int TimeoutSeconds { get; set; } = 10;
}

/// <summary>Результат обращения к API: данные либо понятное сообщение об ошибке.</summary>
public sealed class ApiResult<T>
{
    public bool IsSuccess { get; private init; }
    public T? Data { get; private init; }
    public string? ErrorMessage { get; private init; }
    public HttpStatusCode? StatusCode { get; private init; }

    public static ApiResult<T> Ok(T data) => new() { IsSuccess = true, Data = data };

    public static ApiResult<T> Fail(string message, HttpStatusCode? status = null) =>
        new() { IsSuccess = false, ErrorMessage = message, StatusCode = status };
}

public interface IUniversityApiClient
{
    Task<ApiResult<IReadOnlyList<CourseViewModel>>> GetCoursesAsync(int apiVersion, CancellationToken ct = default);
    Task<ApiResult<CourseViewModel>> GetCourseAsync(int id, int apiVersion, CancellationToken ct = default);
}

/// <summary>
/// HTTP-клиент University Course Management API.
/// Получает данные только по HTTP — к базе данных API напрямую не обращается.
/// </summary>
public sealed class UniversityApiClient : IUniversityApiClient
{
    private readonly HttpClient _http;
    private readonly ILogger<UniversityApiClient> _logger;

    public UniversityApiClient(HttpClient http, ILogger<UniversityApiClient> logger)
    {
        _http = http;
        _logger = logger;
    }

    public Task<ApiResult<IReadOnlyList<CourseViewModel>>> GetCoursesAsync(int apiVersion, CancellationToken ct = default) =>
        SendAsync<IReadOnlyList<CourseViewModel>>($"api/v{Normalize(apiVersion)}/courses", ct);

    public Task<ApiResult<CourseViewModel>> GetCourseAsync(int id, int apiVersion, CancellationToken ct = default) =>
        SendAsync<CourseViewModel>($"api/v{Normalize(apiVersion)}/courses/{id}", ct);

    private static int Normalize(int version) => version == 1 ? 1 : 2;

    private async Task<ApiResult<T>> SendAsync<T>(string path, CancellationToken ct)
    {
        try
        {
            using var response = await _http.GetAsync(path, ct);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("API {Path} returned {StatusCode}", path, (int)response.StatusCode);
                return ApiResult<T>.Fail(DescribeStatus(response.StatusCode), response.StatusCode);
            }

            var data = await response.Content.ReadFromJsonAsync<T>(cancellationToken: ct);
            return data is null
                ? ApiResult<T>.Fail("API вернул пустой ответ.")
                : ApiResult<T>.Ok(data);
        }
        catch (HttpRequestException ex)
        {
            // API не запущен, порт закрыт, ошибка TLS/DNS
            _logger.LogError(ex, "University API is unreachable ({Path})", path);
            return ApiResult<T>.Fail("Не удалось подключиться к University API. Проверьте, что API запущен.");
        }
        catch (TaskCanceledException) when (!ct.IsCancellationRequested)
        {
            _logger.LogError("University API request timed out ({Path})", path);
            return ApiResult<T>.Fail("University API не ответил за отведённое время (timeout).");
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "University API returned invalid JSON ({Path})", path);
            return ApiResult<T>.Fail("University API вернул данные в неожиданном формате.");
        }
    }

    private static string DescribeStatus(HttpStatusCode status) => status switch
    {
        HttpStatusCode.NotFound => "Запрошенный курс не найден (404).",
        HttpStatusCode.Unauthorized => "API требует аутентификацию (401).",
        HttpStatusCode.Forbidden => "Нет прав доступа к ресурсу (403).",
        HttpStatusCode.BadRequest => "Некорректный запрос к API (400).",
        _ when (int)status >= 500 => $"Ошибка на стороне API ({(int)status}). Попробуйте позже.",
        _ => $"API вернул неуспешный код {(int)status}."
    };
}
