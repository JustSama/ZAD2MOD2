# Схема прохождения запроса

Путь запроса от клиента до защищённого ресурса на примере
`PUT /api/v1/enrollments/2/grade` от преподавателя Ахметова (курс CSE3011 ведёт другой преподаватель).

```mermaid
sequenceDiagram
    autonumber
    participant C as Клиент (Postman / Swagger / MVC)
    participant EX as ExceptionHandlingMiddleware
    participant CORS as CORS Middleware
    participant AN as Authentication Middleware (JwtBearer)
    participant AZ as Authorization Middleware
    participant CT as EnrollmentsController
    participant S as EnrollmentService
    participant RH as CourseOwnerHandler
    participant DB as SQLite (EF Core)

    C->>AN: Authorization: Bearer <JWT>
    Note over AN: проверка подписи, Issuer, Audience, exp
    alt токена нет / подпись неверна / истёк
        AN-->>C: 401 Unauthorized (ProblemDetails)
    end
    AN->>AZ: HttpContext.User = claims (sub, unique_name, role, teacher_id)
    Note over AZ: [Authorize(Policy = GradeEditor)] — роль Teacher или Admin
    alt роли нет (например, Student)
        AZ-->>C: 403 Forbidden
    end
    AZ->>CT: вызов действия
    CT->>S: UpdateGradeAsync(2, 50)
    S->>DB: SELECT enrollment + course
    DB-->>S: Course.TeacherId = 2
    S->>RH: AuthorizeAsync(User, course, "CourseOwner")
    Note over RH: teacher_id из JWT (1) == Course.TeacherId (2)?
    RH-->>S: Fail
    S-->>EX: throw ForbiddenAccessException
    EX-->>C: 403 Forbidden (ProblemDetails)
```

## То же самое текстом

```
 Клиент ──HTTP + Authorization: Bearer <JWT>──►
   │
   ├─ 1. ExceptionHandlingMiddleware   ловит исключения всего конвейера → ProblemDetails
   ├─ 2. UseRouting                    выбирает endpoint и его [Authorize]-метаданные
   ├─ 3. UseCors("UniversityClients")  проверяет Origin (два разрешённых клиента)
   ├─ 4. UseAuthentication             JWT → проверка подписи / iss / aud / exp
   │        └─ неуспех + endpoint требует auth  ──► 401 Unauthorized
   │        └─ успех → HttpContext.User (ClaimsPrincipal)
   ├─ 5. UseAuthorization              [Authorize], [AllowAnonymous], роли, политики
   │        └─ не аутентифицирован ──► 401;   нет нужной роли ──► 403
   ├─ 6. Controller → Service          бизнес-логика
   │        └─ ресурсная проверка (IAuthorizationService + Handler):
   │              «этот курс — твой?», «эти оценки — твои?»  ──► иначе 403
   └─ 7. Repository → EF Core → БД  ──► 200 OK + DTO (без конфиденциальных полей)
```

## Где какой компонент

| Компонент | Роль в цепочке | Файл |
|---|---|---|
| ASP.NET Core Identity | хранит пользователей, хеши паролей, роли; проверяет пароль и блокировку | `Program.cs`, `Services/AuthService.cs` |
| JWT | «пропуск», выданный после входа; содержит claims | `Security/JwtTokenService.cs` |
| Authentication Middleware | читает и валидирует JWT, создаёт `HttpContext.User` | `Program.cs` (`AddJwtBearer`) |
| Claims | `sub`, `unique_name`, `role`, `student_id`, `teacher_id` | `Security/SecurityConstants.cs` |
| Roles | `Admin`, `Teacher`, `Student` — грубое разграничение | `Security/SecurityConstants.cs` |
| Authorization Middleware | применяет `[Authorize]`, роли, политики | `Program.cs` (`AddAuthorization`) |
| Resource handlers | проверка владения ресурсом | `Security/ResourceAuthorizationHandlers.cs` |
