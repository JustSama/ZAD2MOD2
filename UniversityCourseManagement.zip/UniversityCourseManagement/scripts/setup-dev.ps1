# Первоначальная настройка (Windows / PowerShell):
#  1) генерирует секретный ключ JWT и кладёт его в User Secrets (вне репозитория);
#  2) применяет миграции и создаёт тестовые роли/пользователей/данные.
# Запуск из корня репозитория:  ./scripts/setup-dev.ps1

$ErrorActionPreference = "Stop"
$api = Join-Path $PSScriptRoot "..\src\UniversityCourseManagement.Api"

$existing = dotnet user-secrets list --project $api 2>$null | Select-String "Jwt:Key"
if (-not $existing) {
    $bytes = New-Object byte[] 48
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    $key = [Convert]::ToBase64String($bytes)
    dotnet user-secrets set "Jwt:Key" $key --project $api | Out-Null
    Write-Host "Jwt:Key сохранён в User Secrets."
    Write-Host "Для сценария 5a в Postman скопируйте ключ: dotnet user-secrets list --project $api"
} else {
    Write-Host "Jwt:Key уже задан в User Secrets."
}

dotnet run --project $api --launch-profile https -- --seed
Write-Host "Готово. Запуск API:    dotnet run --project src/UniversityCourseManagement.Api --launch-profile https"
Write-Host "Запуск клиента:        dotnet run --project src/UniversityCourseManagement.Client --launch-profile https"
