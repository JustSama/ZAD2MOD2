#!/usr/bin/env bash
# Первоначальная настройка (macOS / Linux):
#  1) генерирует секретный ключ JWT и кладёт его в User Secrets (вне репозитория);
#  2) применяет миграции и создаёт тестовые роли/пользователей/данные.
# Запуск из корня репозитория:  bash scripts/setup-dev.sh
set -euo pipefail

API="$(cd "$(dirname "$0")/../src/UniversityCourseManagement.Api" && pwd)"

if ! dotnet user-secrets list --project "$API" 2>/dev/null | grep -q "Jwt:Key"; then
  KEY="$(openssl rand -base64 48)"
  dotnet user-secrets set "Jwt:Key" "$KEY" --project "$API" >/dev/null
  echo "Jwt:Key сохранён в User Secrets."
  echo "Для сценария 5a в Postman скопируйте ключ: dotnet user-secrets list --project $API"
else
  echo "Jwt:Key уже задан в User Secrets."
fi

dotnet run --project "$API" --launch-profile https -- --seed
echo "Готово. Запуск API:   dotnet run --project src/UniversityCourseManagement.Api --launch-profile https"
echo "Запуск клиента:       dotnet run --project src/UniversityCourseManagement.Client --launch-profile https"
