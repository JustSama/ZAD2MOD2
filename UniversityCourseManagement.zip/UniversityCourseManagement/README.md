# University Course Management API — Задание 2

Защищённый, версионируемый ASP.NET Core Web API (.NET 8) с управлением пользователями
и отдельное MVC-приложение-клиент.

| Что | Где |
|---|---|
| Web API | `src/UniversityCourseManagement.Api` |
| MVC-клиент (IHttpClientFactory) | `src/UniversityCourseManagement.Client` |
| Миграции EF Core | `src/UniversityCourseManagement.Api/Data/Migrations` |
| Тестовые роли и пользователи | `Data/DbSeeder.cs` + `scripts/setup-dev.*` |
| Postman-коллекция (12 сценариев) | `postman/UniversityCourseManagement.postman_collection.json` |
| `.http`-файл для VS / Rider | `src/UniversityCourseManagement.Api/UniversityCourseManagement.Api.http` |
| Схема прохождения запроса | `docs/request-flow.md` |

---

## 1. Требования

- .NET SDK 8.0
- Доверенный dev-сертификат HTTPS: `dotnet dev-certs https --trust`
- (необязательно) `dotnet-ef` для новых миграций: `dotnet tool install --global dotnet-ef`

База данных — SQLite (`university.db` создаётся автоматически), установка СУБД не нужна.

## 2. Запуск

```bash
# 1. Секретный ключ JWT в User Secrets + миграции + тестовые данные
./scripts/setup-dev.ps1          # Windows
bash scripts/setup-dev.sh        # macOS / Linux

# 2. API  → https://localhost:7100/swagger
dotnet run --project src/UniversityCourseManagement.Api --launch-profile https

# 3. Клиент (в другом терминале) → https://localhost:7201
dotnet run --project src/UniversityCourseManagement.Client --launch-profile https
```

Ручная установка ключа вместо скрипта:

```bash
dotnet user-secrets set "Jwt:Key" "<случайная строка не короче 32 символов>" --project src/UniversityCourseManagement.Api
```

Без `Jwt:Key` API **не запустится** (fail-fast в `JwtOptions.Validate`). На сервере ключ задаётся
переменной окружения `Jwt__Key`. В `appsettings*.json` и в Git ключа нет.

### Тестовые пользователи (только Development)

Пароль у всех: `Passw0rd!` (задан в `appsettings.Development.json → Seed:DefaultPassword`).

| Логин | Роль | Связан с |
|---|---|---|
| `admin` | Admin | — |
| `teacher.akhmetov` | Teacher | Teacher #1 (ведёт CSE5032, CSE2104) |
| `teacher.sadykova` | Teacher | Teacher #2 (ведёт CSE3011) |
| `student.aliyev` | Student | Student #1 (записи #1, #2) |
| `student.serikova` | Student | Student #2 (записи #3, #4) |

Записи на курсы: #1 Алиев–CSE5032, #2 Алиев–CSE3011, #3 Серикова–CSE5032, #4 Серикова–CSE2104, #5 Жумабаев–CSE3011.

## 3. Что реализовано

### 3.1 Web API, CORS, HTTP-клиент
- Именованная CORS-политика `UniversityClients`, два адреса клиента в `appsettings.json → Cors:AllowedOrigins`.
- MVC-клиент: `AddHttpClient<IUniversityApiClient, UniversityApiClient>` (IHttpClientFactory), адрес API — `appsettings.json → UniversityApi:BaseUrl`.
- Клиент показывает список курсов и детали курса, переключатель v1/v2.
- Обработка ошибок: API выключен (`HttpRequestException`), timeout, неуспешные коды (404, 5xx…), неверный JSON — пользователь видит понятное сообщение, приложение не падает.

### 3.2 Публичные и защищённые endpoints

| Endpoint | Аноним | Student | Teacher | Admin |
|---|---|---|---|---|
| `GET /api/v{1,2}/courses[/{id}]` | ✅ | ✅ | ✅ | ✅ |
| `GET /api/v1/teachers[/{id}]` | ✅ | ✅ | ✅ | ✅ |
| `POST/PUT/DELETE` courses, teachers, students | 401 | 403 | 403 | ✅ |
| `GET /api/v1/students` | 401 | 403 | ✅ | ✅ |
| `GET /api/v1/students/{id}` | 401 | только свой | ✅ | ✅ |
| `GET /api/v1/students/{id}/enrollments` (оценки) | 401 | только свои | 403 | ✅ |
| `GET /api/v1/courses/{id}/enrollments` | 401 | 403 | только свой курс | ✅ |
| `PUT /api/v1/enrollments/{id}/grade` | 401 | 403 | только свой курс | ✅ |
| `POST /api/v1/enrollments` | 401 | только себя | 403 | ✅ |
| `DELETE /api/v1/enrollments/{id}` | 401 | 403 | 403 | ✅ |
| `/api/users/*`, `/api/roles` | 401 | 403 | 403 | ✅ |
| `POST /api/auth/register`, `/login` | ✅ | ✅ | ✅ | ✅ |
| `GET /api/auth/me` | 401 | ✅ | ✅ | ✅ |

- 401 — нет токена, токен просрочен, подпись изменена, неверный issuer/audience.
- 403 — токен валиден, но не хватает роли или ресурс принадлежит другому пользователю.
- Ответы 401/403/404/409 — в едином формате ProblemDetails (`application/problem+json`).
- `UserDto` не содержит `PasswordHash`, `SecurityStamp`, `ConcurrencyStamp`; `StudentDto/TeacherDto` не содержат `UserId`.

### 3.3 JWT
- `POST /api/auth/login` → `{ accessToken, tokenType: "Bearer", expiresAtUtc, userName, roles }`.
- Claims: `sub` (Id), `unique_name` (логин), `role` (роли), `student_id` / `teacher_id`, `jti`.
- Проверяются подпись (HS256), `iss`, `aud`, `exp`; `ClockSkew = 0`.
- Срок жизни — `Jwt:AccessTokenMinutes` (15 мин).

### 3.4 ASP.NET Core Identity
- `AddIdentityCore<ApplicationUser>().AddRoles<IdentityRole>().AddEntityFrameworkStores<AppDbContext>().AddSignInManager()`.
- Регистрация — `UserManager.CreateAsync`; вход — `SignInManager.CheckPasswordSignInAsync(..., lockoutOnFailure: true)`.
- Пароль: ≥ 8 символов, цифра, строчная и заглавная буква. Хеш — стандартный `PasswordHasher` Identity.
- Блокировка: 5 неудачных попыток → 5 минут (ответ 423 Locked). Снять: `POST /api/users/{id}/unlock`.
- Одинаковые логины запрещены (409 Conflict), email тоже уникален.
- Регистрация выдаёт только роль Student; в `RegisterRequest` нет поля роли.

### 3.5 Роли и владение ресурсами
- Роли `Admin`, `Teacher`, `Student` создаются сидером через `RoleManager`.
- Политики: `AdminOnly`, `Staff`, `GradeEditor` (роли) + `CourseOwner`, `StudentDataOwner`, `EnrollmentViewer` (ресурсные, `AuthorizationHandler<TRequirement, TResource>`).
- `Teacher.UserId` / `Student.UserId` — связь аккаунта с сущностью; связывает Admin: `PUT /api/users/{id}/teacher|student`.
- Проверка владения выполняется в сервисах на сервере, независимо от клиента.
- Повышение привилегий: роли меняет только Admin; Admin не может снять Admin сам с себя.

### 3.6 Версионирование
- `Asp.Versioning.Mvc`, версия в URL: `/api/v1/...`, `/api/v2/...`, заголовок `api-supported-versions`.
- v1 `CourseDto` не изменён; v2 `CourseDetailsV2Dto` + `CourseTeacherV2Dto` (преподаватель и `enrolledStudentsCount`).
- Логика одна — `ICourseService.GetAllAsync<TDto>()`; контроллеры v1/v2 отличаются только типом DTO.
- Swagger: два документа (V1, V2) в выпадающем списке, кнопка **Authorize** для JWT.

## 4. Сценарии безопасности (раздел 7)

Postman: импортировать коллекцию → выполнить папку «0. Подготовка» → «Сценарии раздела 7» (Runner).
Для сценария 5a задайте переменную коллекции `jwtKey` = ключ из `dotnet user-secrets list`.

| № | Сценарий | Запрос | Результат |
|---|---|---|---|
| 1 | Аноним: список курсов | `GET /api/v1/courses` | 200 |
| 2 | Аноним: создать курс | `POST /api/v1/courses` | 401 |
| 3 | Неверный пароль | `POST /api/auth/login` | 401, JWT не выдан |
| 4 | Верные данные | `POST /api/auth/login` | 200 + JWT |
| 5 | Просроченный JWT | `GET /api/auth/me` | 401 «Срок действия токена истёк» |
| 6 | Student удаляет курс | `DELETE /api/v1/courses/1` | **403** (см. примечание) |
| 7 | Teacher, свой курс | `PUT /api/v1/enrollments/1/grade` (teacher.akhmetov) | 200 |
| 8 | Teacher, чужой курс | `PUT /api/v1/enrollments/2/grade` (teacher.akhmetov) | 403 |
| 9 | Student, чужие оценки | `GET /api/v1/students/2/enrollments` (student.aliyev) | 403 |
| 10 | Admin назначает роль | `POST /api/users/{id}/roles` | 200 |
| 11 | Student назначает себе Admin | `POST /api/users/{свой id}/roles` | 403 |
| 12 | v1 и v2 | `GET /api/v1/courses/1`, `GET /api/v2/courses/1` | оба 200, разные контракты |

> **Примечание к сценарию 6.** В таблице задания указан 401, но раздел 2 задания требует
> 403 для аутентифицированного пользователя без прав. Student с валидным токеном получает **403**;
> 401 будет, если запрос отправлен без токена или с недействительным токеном. На защите
> можно показать оба варианта.

Просроченный токен вручную: задайте `Jwt__AccessTokenMinutes=1`, войдите, подождите минуту.

## 5. Демонстрация совместимости v1 / v2

1. Клиент: `https://localhost:7201/Courses?v=1` и `?v=2` — обе версии работают одновременно.
2. Postman 12a проверяет, что в ответе v1 есть `teacherId` и **нет** `teacher`, т.е. расширение v2 не изменило контракт v1.

## 6. Новая миграция (при изменении модели)

```bash
dotnet ef migrations add <Name> --project src/UniversityCourseManagement.Api --output-dir Data/Migrations
```

## 7. Структура API

```
Controllers/        AuthController, UsersController (+Roles), V1/*, V2/CoursesController
Services/           бизнес-логика (общая для v1 и v2), Auth, UserManagement
Repositories/       IRepository<T> / Repository<T>
DTOs/               контракты, в т.ч. отдельные DTO v2
Mapping/            AutoMapper profile
Security/           константы ролей/политик/claims, JwtTokenService, ресурсные handlers, CurrentUser
Middleware/         ExceptionHandlingMiddleware (ProblemDetails)
Data/               AppDbContext (IdentityDbContext), DbSeeder, Migrations
Swagger/            ConfigureSwaggerOptions (документ на каждую версию + Bearer)
```
